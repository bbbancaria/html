# Sistema de Gerenciamento de Restaurante

## 📋 Descrição
Sistema web para gerenciamento de vendas e mesas de restaurante, desenvolvido com PHP, MySQL e JavaScript.

## 🚀 Funcionalidades

### Gerenciamento de Mesas
- Visualização de todas as mesas
- Status em tempo real (livre, ocupada, reservada)
- Criação de novas mesas
- Exclusão de mesas

### Controle de Vendas
- Abertura de vendas por mesa
- Adição de produtos
- Cálculo automático do total
- Cancelamento de vendas
- Histórico de vendas

### Produtos e Categorias
- Cadastro de produtos
- Organização por categorias
- Preços e descrições
- Status de disponibilidade

## 🛠️ Tecnologias Utilizadas

### Frontend
- HTML5
- CSS3 (Bootstrap 5.1.3)
- JavaScript
- jQuery 3.6.0
- SweetAlert2 (para notificações)

### Backend
- PHP 7.4+
- MySQL 5.7+
- PDO para conexão com banco de dados

## 📦 Estrutura do Banco de Dados

### Tabelas Principais

#### mesas
```sql
CREATE TABLE mesas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(10) NOT NULL,
    status ENUM('livre', 'ocupada', 'reservada') DEFAULT 'livre',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

#### vendas
```sql
CREATE TABLE vendas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    mesa_id INT,
    status ENUM('em_andamento', 'finalizada', 'cancelada') DEFAULT 'em_andamento',
    total DECIMAL(10,2) DEFAULT 0.00,
    data_venda DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (mesa_id) REFERENCES mesas(id)
);
```

#### produtos
```sql
CREATE TABLE produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10,2) NOT NULL,
    categoria_id INT,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

## 📁 Estrutura de Arquivos

```
├── api/
│   ├── deletar_venda.php
│   ├── listar_mesas.php
│   └── nova_mesa.php
├── assets/
│   ├── css/
│   └── js/
│       └── vendas.js
├── includes/
│   └── conexao.php
├── sql/
│   ├── sistema_lanchonete.sql
│   └── verificar_tabelas.sql
└── vendas.php
```

## 🔧 Instalação

1. Clone o repositório
2. Configure o banco de dados em `includes/conexao.php`
3. Execute os scripts SQL em `sql/`
4. Configure o servidor web (Apache/Nginx)

### Requisitos do Servidor
- PHP 7.4 ou superior
- MySQL 5.7 ou superior
- Extensão PDO habilitada
- mod_rewrite (Apache) habilitado

### Configuração do Banco de Dados
```php
$host = 'localhost';
$dbname = 'erpmon62_sistema_lanchonete';
$username = 'seu_usuario';
$password = 'sua_senha';
```

## 🔌 API Endpoints

### GET /api/listar_mesas.php
Lista todas as mesas com seus status e vendas em andamento.

### POST /api/nova_mesa.php
Cria uma nova venda em uma mesa.
- Parâmetros: `mesa_id`

### POST /api/deletar_venda.php
Cancela uma venda e libera a mesa.
- Parâmetros: `venda_id`

## 🔐 Segurança

- Uso de prepared statements para prevenção de SQL Injection
- Validação de dados de entrada
- Tratamento de erros com logs
- Transações para integridade dos dados

## 🚦 Status dos Códigos de Resposta

- 200: Sucesso
- 400: Erro de validação
- 404: Recurso não encontrado
- 500: Erro interno do servidor

## 💻 Interface do Usuário

### Tela de Vendas
- Lista de mesas com status
- Botões de ação por mesa
- Indicadores visuais de status
- Modal de confirmação para ações importantes

## 🔄 Fluxo de Venda

1. Cliente ocupa uma mesa
2. Sistema registra mesa como ocupada
3. Garçom adiciona produtos à venda
4. Sistema calcula total automaticamente
5. Venda pode ser finalizada ou cancelada
6. Mesa é liberada após finalização

## ⚠️ Tratamento de Erros

- Validação de dados em frontend e backend
- Mensagens de erro amigáveis ao usuário
- Log detalhado de erros no servidor
- Rollback de transações em caso de falha

## 🔍 Monitoramento

- Log de erros em arquivo
- Registro de todas as operações críticas
- Histórico de vendas e alterações
- Status em tempo real das mesas

## 🔜 Futuras Implementações

- [ ] Sistema de autenticação de usuários
- [ ] Relatórios gerenciais
- [ ] Controle de estoque
- [ ] Integração com impressoras
- [ ] App mobile para garçons

## 📱 Responsividade

O sistema é responsivo e funciona em:
- Desktops
- Tablets
- Smartphones

## 🤝 Suporte

Para suporte, envie um email para [seu-email@dominio.com]

## 📄 Licença

Este projeto está sob a licença MIT. Veja o arquivo LICENSE para mais detalhes.
