<?php
// Configurações de CORS
header('Access-Control-Allow-Origin: http://localhost');
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Accept');
header('Access-Control-Allow-Credentials: true');

// Se for uma requisição OPTIONS, retorna apenas os headers
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit;
}

header('Content-Type: application/json');
session_start();

require_once '../includes/conexao.php';

// Ativa log de erros
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Log para debug
error_log("Iniciando finalização de venda");

try {
    // Recebe os dados da venda
    $rawData = file_get_contents('php://input');
    error_log("Dados recebidos: " . $rawData);
    
    $dados = json_decode($rawData, true);
    
    if (!$dados) {
        throw new Exception('Dados inválidos ou mal formatados: ' . json_last_error_msg());
    }

    // Valida os dados necessários
    if (empty($dados['mesa'])) {
        throw new Exception('Mesa não informada');
    }
    if (empty($dados['garcom'])) {
        throw new Exception('Garçom não informado');
    }
    if (empty($dados['itens'])) {
        throw new Exception('Nenhum item informado');
    }
    if (empty($dados['pagamentos'])) {
        throw new Exception('Nenhuma forma de pagamento informada');
    }
    if (!isset($dados['total']) || !is_numeric($dados['total'])) {
        throw new Exception('Total da venda inválido');
    }

    // Converte o ID do garçom para inteiro
    $garcom_id = intval($dados['garcom']);
    if ($garcom_id <= 0) {
        throw new Exception('ID do garçom inválido');
    }

    // Log dos dados processados
    error_log("Mesa: " . $dados['mesa']);
    error_log("Garçom ID: " . $garcom_id);
    error_log("Total de itens: " . count($dados['itens']));
    error_log("Total de pagamentos: " . count($dados['pagamentos']));

    // Inicia a transação
    $pdo->beginTransaction();
    error_log("Transação iniciada");

    try {
        // Insere a venda
        $stmt = $pdo->prepare("
            INSERT INTO vendas (mesa, garcom, total, data_venda, status)
            VALUES (:mesa, :garcom, :total, NOW(), 'concluida')
        ");

        $params = [
            ':mesa' => $dados['mesa'],
            ':garcom' => $garcom_id,
            ':total' => $dados['total']
        ];
        
        error_log("Inserindo venda com parâmetros: " . json_encode($params));
        $stmt->execute($params);

        $venda_id = $pdo->lastInsertId();
        error_log("Venda inserida com ID: " . $venda_id);

        // Insere os itens da venda
        $stmt = $pdo->prepare("
            INSERT INTO itens_venda (venda_id, produto_id, quantidade, preco_unitario, subtotal)
            VALUES (:venda_id, :produto_id, :quantidade, :preco_unitario, :subtotal)
        ");

        foreach ($dados['itens'] as $item) {
            $subtotal = $item['quantidade'] * $item['preco'];
            $itemParams = [
                ':venda_id' => $venda_id,
                ':produto_id' => $item['id'],
                ':quantidade' => $item['quantidade'],
                ':preco_unitario' => $item['preco'],
                ':subtotal' => $subtotal
            ];
            error_log("Inserindo item com parâmetros: " . json_encode($itemParams));
            $stmt->execute($itemParams);
        }

        // Insere os pagamentos
        $stmt = $pdo->prepare("
            INSERT INTO pagamentos_venda (venda_id, forma_pagamento, valor)
            VALUES (:venda_id, :forma_pagamento, :valor)
        ");

        foreach ($dados['pagamentos'] as $pagamento) {
            $pagamentoParams = [
                ':venda_id' => $venda_id,
                ':forma_pagamento' => $pagamento['forma'],
                ':valor' => $pagamento['valor']
            ];
            error_log("Inserindo pagamento com parâmetros: " . json_encode($pagamentoParams));
            $stmt->execute($pagamentoParams);
        }

        // Confirma a transação
        $pdo->commit();
        error_log("Transação confirmada");

        echo json_encode([
            'success' => true,
            'message' => 'Venda finalizada com sucesso',
            'id' => $venda_id
        ]);

    } catch (Exception $e) {
        // Em caso de erro, desfaz a transação
        $pdo->rollBack();
        error_log("Erro na transação: " . $e->getMessage());
        throw $e;
    }

} catch (Exception $e) {
    error_log("Erro ao finalizar venda: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'success' => false,
        'message' => 'Erro ao finalizar venda: ' . $e->getMessage()
    ]);
}
