<?php
header('Content-Type: application/json');
require_once '../includes/conexao.php';

try {
    if (!isset($_POST['venda_id'])) {
        throw new Exception('ID da venda não fornecido');
    }

    $venda_id = intval($_POST['venda_id']);
    
    // Inicia a transação
    $pdo->beginTransaction();
    
    // Busca o ID da mesa
    $stmt = $pdo->prepare("SELECT mesa_id FROM vendas WHERE venda_id = ?");
    $stmt->execute([$venda_id]);
    $venda = $stmt->fetch();
    
    if (!$venda) {
        throw new Exception('Venda não encontrada');
    }
    
    $mesa_id = $venda['mesa_id'];
    
    // Deleta os pagamentos relacionados
    $stmt = $pdo->prepare("DELETE FROM pagamentos_venda WHERE venda_id = ?");
    $stmt->execute([$venda_id]);
    
    // Deleta a venda
    $stmt = $pdo->prepare("DELETE FROM vendas WHERE venda_id = ?");
    $stmt->execute([$venda_id]);
    
    // Atualiza o status da mesa para livre
    $stmt = $pdo->prepare("UPDATE mesas SET status = 'livre' WHERE id = ?");
    $stmt->execute([$mesa_id]);
    
    // Confirma a transação
    $pdo->commit();
    
    echo json_encode([
        'status' => 'success',
        'message' => 'Mesa liberada com sucesso'
    ]);

} catch (Exception $e) {
    // Em caso de erro, desfaz a transação
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        'status' => 'error',
        'message' => 'Erro ao liberar mesa: ' . $e->getMessage()
    ]);
}
