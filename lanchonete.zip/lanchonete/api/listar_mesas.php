<?php
header('Content-Type: application/json');
require_once '../includes/conexao.php';

try {
    // Busca todas as mesas em preparo
    $sql = "
        SELECT 
            m.id,
            m.numero,
            m.status as mesa_status,
            v.id as venda_id,
            v.total,
            'Dani' as garcom,
            GROUP_CONCAT(
                CONCAT(COALESCE(i.quantidade, ''), 'x ', COALESCE(p.nome, ''))
                SEPARATOR '\n'
            ) as produtos
        FROM mesas m
        LEFT JOIN vendas v ON m.id = v.mesa_id AND v.status = 'em_andamento'
        LEFT JOIN itens_venda i ON v.id = i.venda_id
        LEFT JOIN produtos p ON i.produto_id = p.id
        GROUP BY m.id, v.id
        ORDER BY m.numero ASC
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute();
    $mesas = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Se não houver mesas, retorna array vazio
    if (empty($mesas)) {
        echo json_encode([]);
        exit;
    }
    
    // Formata os dados antes de retornar
    $mesas = array_map(function($mesa) {
        return [
            'id' => $mesa['id'],
            'numero' => $mesa['numero'],
            'status' => $mesa['mesa_status'],
            'venda_id' => $mesa['venda_id'],
            'total' => $mesa['total'] ? number_format($mesa['total'], 2, '.', '') : '0.00',
            'garcom' => $mesa['garcom'],
            'produtos' => $mesa['produtos'] ?: ''
        ];
    }, $mesas);
    
    echo json_encode($mesas);

} catch (PDOException $e) {
    error_log("Erro ao listar mesas: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Erro ao listar mesas. Por favor, tente novamente.'
    ]);
} catch (Exception $e) {
    error_log("Erro inesperado: " . $e->getMessage());
    http_response_code(500);
    echo json_encode([
        'status' => 'error',
        'message' => 'Ocorreu um erro inesperado. Por favor, tente novamente.'
    ]);
}
