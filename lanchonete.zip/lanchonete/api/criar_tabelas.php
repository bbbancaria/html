<?php
require_once '../includes/conexao.php';

try {
    // Cria a tabela vendas se não existir
    $pdo->exec("CREATE TABLE IF NOT EXISTS vendas (
        id_venda BIGINT PRIMARY KEY,
        mesa VARCHAR(50),
        garcom VARCHAR(100),
        total DECIMAL(10,2) NOT NULL,
        data_venda DATETIME NOT NULL,
        status ENUM('em_andamento', 'finalizada', 'cancelada') DEFAULT 'em_andamento',
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Cria a tabela itens_venda se não existir
    $pdo->exec("CREATE TABLE IF NOT EXISTS itens_venda (
        id INT AUTO_INCREMENT PRIMARY KEY,
        id_venda BIGINT NOT NULL,
        id_produto INT NOT NULL,
        quantidade INT NOT NULL,
        preco_unitario DECIMAL(10,2) NOT NULL,
        subtotal DECIMAL(10,2) NOT NULL,
        FOREIGN KEY (id_venda) REFERENCES vendas(id_venda)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    // Cria a tabela pagamentos_venda se não existir
    $pdo->exec("CREATE TABLE IF NOT EXISTS pagamentos_venda (
        id INT AUTO_INCREMENT PRIMARY KEY,
        id_venda BIGINT NOT NULL,
        forma_pagamento VARCHAR(50) NOT NULL,
        valor DECIMAL(10,2) NOT NULL,
        FOREIGN KEY (id_venda) REFERENCES vendas(id_venda)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;");

    echo json_encode(['success' => true, 'message' => 'Tabelas criadas com sucesso']);
} catch (PDOException $e) {
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Erro ao criar tabelas: ' . $e->getMessage()]);
}
