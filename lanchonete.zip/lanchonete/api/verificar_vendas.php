<?php
require_once '../includes/conexao.php';

header('Content-Type: text/plain');

try {
    // Verifica vendas
    $stmt = $pdo->query("SELECT * FROM vendas ORDER BY data_venda DESC LIMIT 5");
    echo "Últimas 5 vendas:\n";
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        print_r($row);
    }

    // Verifica itens_venda
    $stmt = $pdo->query("SELECT * FROM itens_venda ORDER BY id DESC LIMIT 5");
    echo "\n\nÚltimos 5 itens vendidos:\n";
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        print_r($row);
    }

    // Verifica pagamentos
    $stmt = $pdo->query("SELECT * FROM pagamentos_venda ORDER BY id DESC LIMIT 5");
    echo "\n\nÚltimos 5 pagamentos:\n";
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        print_r($row);
    }

} catch (PDOException $e) {
    echo "Erro ao verificar vendas: " . $e->getMessage();
}
