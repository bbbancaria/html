<?php
require_once '../includes/conexao.php';

header('Content-Type: text/plain');

try {
    // Verifica a estrutura da tabela vendas
    $stmt = $pdo->query("SHOW CREATE TABLE vendas");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "Estrutura da tabela vendas:\n";
    print_r($result);

    // Verifica a estrutura da tabela itens_venda
    $stmt = $pdo->query("SHOW CREATE TABLE itens_venda");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "\n\nEstrutura da tabela itens_venda:\n";
    print_r($result);

    // Verifica a estrutura da tabela pagamentos_venda
    $stmt = $pdo->query("SHOW CREATE TABLE pagamentos_venda");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    echo "\n\nEstrutura da tabela pagamentos_venda:\n";
    print_r($result);

} catch (PDOException $e) {
    echo "Erro ao verificar tabelas: " . $e->getMessage();
}
