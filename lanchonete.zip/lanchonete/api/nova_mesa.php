<?php
header('Content-Type: application/json');
require_once '../includes/conexao.php';

try {
    if (!isset($_POST['mesa_id'])) {
        throw new Exception('ID da mesa não fornecido');
    }

    $mesa_id = intval($_POST['mesa_id']);
    
    // Inicia a transação
    $pdo->beginTransaction();
    
    // Verifica se a mesa existe e está livre
    $stmt = $pdo->prepare("
        SELECT id, status 
        FROM mesas 
        WHERE id = ? AND status = 'livre'
    ");
    $stmt->execute([$mesa_id]);
    $mesa = $stmt->fetch();
    
    if (!$mesa) {
        throw new Exception('Mesa não encontrada ou não está livre');
    }
    
    // Atualiza o status da mesa para ocupada
    $stmt = $pdo->prepare("UPDATE mesas SET status = 'ocupada' WHERE id = ?");
    $stmt->execute([$mesa_id]);
    
    // Insere a nova venda
    $stmt = $pdo->prepare("
        INSERT INTO vendas (mesa_id, status, total, data_venda) 
        VALUES (?, 'em_andamento', 0.00, NOW())
    ");
    $stmt->execute([$mesa_id]);
    
    $venda_id = $pdo->lastInsertId();
    
    // Confirma a transação
    $pdo->commit();
    
    echo json_encode([
        'status' => 'success',
        'message' => 'Venda iniciada com sucesso',
        'venda_id' => $venda_id
    ]);

} catch (Exception $e) {
    // Em caso de erro, desfaz a transação
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    
    echo json_encode([
        'status' => 'error',
        'message' => 'Erro ao iniciar venda: ' . $e->getMessage()
    ]);
}
