<?php
require_once 'includes/conexao.php';

try {
    // Check usuarios table
    $stmt = $pdo->query("SELECT * FROM usuarios WHERE nome = 'Dane' AND tipo = 'garcom'");
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($usuario) {
        echo "Garçom Dane encontrado na tabela usuarios com ID: " . $usuario['id'] . "\n";
    } else {
        echo "Garçom Dane não encontrado na tabela usuarios.\n";
    }

    // Check garcons table
    $stmt = $pdo->query("SELECT * FROM garcons WHERE nome = 'Dane'");
    $garcom = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($garcom) {
        echo "Garçom Dane encontrado na tabela garcons com ID: " . $garcom['id'] . "\n";
    } else {
        echo "Garçom Dane não encontrado na tabela garcons.\n";
    }

    // Show all active garçons in usuarios table
    echo "\nTodos os garçons ativos na tabela usuarios:\n";
    $stmt = $pdo->query("SELECT id, nome, tipo, status FROM usuarios WHERE tipo = 'garcom' AND status = 'ativo'");
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        echo "ID: " . $row['id'] . ", Nome: " . $row['nome'] . ", Tipo: " . $row['tipo'] . ", Status: " . $row['status'] . "\n";
    }
} catch (PDOException $e) {
    echo "Erro ao verificar garçom: " . $e->getMessage();
}
?>
