<?php
require_once 'includes/conexao.php';

try {
    // Criar tabela de sócias
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS socias (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100) NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
    ");

    // Adicionar coluna socia_id na tabela produtos
    $pdo->exec("
        ALTER TABLE produtos
        ADD COLUMN IF NOT EXISTS socia_id INT,
        ADD FOREIGN KEY (socia_id) REFERENCES socias(id);
    ");

    // Inserir as sócias
    $stmt = $pdo->prepare("INSERT INTO socias (nome) VALUES (?), (?)");
    $stmt->execute(['Silvania', 'Suely']);

    echo "Tabelas e dados das sócias criados com sucesso!";

} catch(PDOException $e) {
    die("Erro: " . $e->getMessage());
}
