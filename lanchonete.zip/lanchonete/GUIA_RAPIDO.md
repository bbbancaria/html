# 📱 Guia Rápido - Sistema de Restaurante

## 🏃 Início Rápido

### Gerenciando Mesas

1. **Visualizar Mesas**
   - Acesse a tela principal
   - Veja todas as mesas e seus status
   - Verde = Mesa livre
   - Amarelo = Mesa ocupada

2. **Iniciar Venda**
   - Clique em "Nova Venda" em uma mesa livre
   - A mesa ficará marcada como ocupada
   - O sistema abrirá a tela de venda

3. **Adicionar Produtos**
   - Na tela da venda, busque o produto
   - Defina a quantidade
   - Clique em adicionar
   - O total será atualizado automaticamente

4. **Cancelar Venda**
   - Clique em "Deletar" na mesa
   - Confirme a ação
   - A mesa será liberada automaticamente

## 🎯 Dicas Rápidas

- **Cores dos Status**
  - 🟢 Verde = Mesa Livre
  - 🟡 Amarelo = Em Preparo
  - 🔴 Vermelho = Conta Solicitada

- **Atalhos**
  - F5 = Atualizar tela
  - ESC = Fechar modal

## ⚠️ Problemas Comuns

1. **Tela não atualiza**
   - Pressione F5
   - Verifique sua conexão

2. **Erro ao salvar**
   - Verifique os dados
   - Tente novamente
   - Contate suporte se persistir

## 📞 Suporte

- Horário: 8h às 18h
- Email: suporte@sistema.com
- Tel: (XX) XXXX-XXXX
