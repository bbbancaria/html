-- Tabela de usuários (para garçons, administradores, etc.)
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    nivel ENUM('admin', 'garcom', 'caixa') NOT NULL,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de categorias de produtos
CREATE TABLE IF NOT EXISTS categorias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL,
    descricao TEXT,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de produtos
CREATE TABLE IF NOT EXISTS produtos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    descricao TEXT,
    preco DECIMAL(10,2) NOT NULL,
    categoria_id INT,
    estoque INT DEFAULT 0,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    imagem_url VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (categoria_id) REFERENCES categorias(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de itens da venda
CREATE TABLE IF NOT EXISTS itens_venda (
    id INT AUTO_INCREMENT PRIMARY KEY,
    venda_id INT NOT NULL,
    produto_id INT NOT NULL,
    quantidade INT NOT NULL,
    preco_unitario DECIMAL(10,2) NOT NULL,
    subtotal DECIMAL(10,2) NOT NULL,
    observacao TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (produto_id) REFERENCES produtos(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de vendas
CREATE TABLE IF NOT EXISTS vendas (
    venda_id INT AUTO_INCREMENT PRIMARY KEY,
    mesa VARCHAR(10),
    status ENUM('em_andamento', 'finalizada', 'cancelada') DEFAULT 'em_andamento',
    total DECIMAL(10,2) NOT NULL,
    data_venda DATETIME DEFAULT CURRENT_TIMESTAMP,
    financeiro_id INT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Tabela de pagamentos da venda
CREATE TABLE IF NOT EXISTS pagamentos_venda (
    pagamento_id INT AUTO_INCREMENT PRIMARY KEY,
    venda_id INT NOT NULL,
    forma_pagamento ENUM('dinheiro', 'cartao_credito', 'cartao_debito', 'pix') NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    data_pagamento DATETIME DEFAULT CURRENT_TIMESTAMP,
    financeiro_id INT,
    FOREIGN KEY (venda_id) REFERENCES vendas(venda_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Inserindo dados iniciais

-- Inserindo usuário administrador
INSERT INTO usuarios (nome, email, senha, nivel) VALUES 
('Administrador', 'admin@admin.com', '$2y$10$8tDjcKhF.gRHqyH1Wl9jZOvtQrjhkEhj8Z5Z5Z5Z5Z5Z5Z5Z5Z', 'admin');

-- Inserindo categorias básicas
INSERT INTO categorias (nome, descricao) VALUES 
('Lanches', 'Hambúrgueres, hot dogs e sanduíches'),
('Bebidas', 'Refrigerantes, sucos e água'),
('Porções', 'Batata frita, onion rings e outros'),
('Sobremesas', 'Sorvetes, milk shakes e doces');

-- Inserindo produtos
INSERT INTO produtos (nome, descricao, preco, categoria_id, estoque) VALUES 
('X-Burger', 'Hambúrguer com queijo', 15.90, 1, 100),
('X-Salada', 'Hambúrguer com queijo e salada', 17.90, 1, 100),
('Coca-Cola 350ml', 'Refrigerante Coca-Cola lata', 5.00, 2, 200),
('Batata Frita P', 'Porção pequena de batata frita', 12.90, 3, 100),
('Milk Shake', 'Milk shake de chocolate', 13.90, 4, 50);

-- Trigger para inserir no financeiro quando finalizar uma venda
DELIMITER //
CREATE TRIGGER after_venda_finalizada
AFTER UPDATE ON vendas
FOR EACH ROW
BEGIN
    IF NEW.status = 'finalizada' AND (OLD.status != 'finalizada' OR OLD.status IS NULL) THEN
        INSERT INTO financeiro (descricao, valor, tipo, data_movimentacao)
        VALUES (CONCAT('Venda #', NEW.venda_id), NEW.total, 'Entrada', NEW.data_venda);
        
        SET @last_financeiro_id = LAST_INSERT_ID();
        
        UPDATE vendas 
        SET financeiro_id = @last_financeiro_id
        WHERE venda_id = NEW.venda_id;
    END IF;
END //
DELIMITER ;

-- Criando índices para melhor performance
CREATE INDEX idx_produtos_categoria ON produtos(categoria_id);
CREATE INDEX idx_produtos_status ON produtos(status);
CREATE INDEX idx_vendas_status ON vendas(status);
CREATE INDEX idx_vendas_data ON vendas(data_venda);
CREATE INDEX idx_vendas_codigo ON vendas(venda_id);
CREATE INDEX idx_vendas_financeiro ON vendas(financeiro_id);
CREATE INDEX idx_itens_venda_produto ON itens_venda(produto_id);
CREATE INDEX idx_pagamentos_venda ON pagamentos_venda(venda_id);
CREATE INDEX idx_pagamentos_forma ON pagamentos_venda(forma_pagamento);
CREATE INDEX idx_pagamentos_financeiro ON pagamentos_venda(financeiro_id);
