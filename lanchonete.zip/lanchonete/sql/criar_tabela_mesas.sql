-- Tabela de mesas
CREATE TABLE mesas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    numero VARCHAR(10) NOT NULL,
    status ENUM('livre', 'ocupada', 'reservada') DEFAULT 'livre',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Adicionando chave única para número da mesa
ALTER TABLE mesas ADD UNIQUE INDEX idx_numero_mesa (numero);

-- Alterando a tabela vendas para referenciar a tabela mesas
ALTER TABLE vendas ADD COLUMN mesa_id INT AFTER venda_id;
ALTER TABLE vendas ADD FOREIGN KEY (mesa_id) REFERENCES mesas(id);

-- Inserindo algumas mesas padrão
INSERT INTO mesas (numero) VALUES 
('1'), ('2'), ('3'), ('4'), ('5'),
('6'), ('7'), ('8'), ('9'), ('10'),
('11'), ('12'), ('13'), ('14'), ('15'),
('16'), ('17'), ('18'), ('19'), ('20');
