-- Criar tabela de usuários se não existir
CREATE TABLE IF NOT EXISTS usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(64) NOT NULL, -- Para armazenar hash SHA-256
    tipo ENUM('admin', 'funcionario') NOT NULL DEFAULT 'funcionario',
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY idx_login (login)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Inserir usuário admin padrão se não existir (senha: admin123)
INSERT INTO usuarios (nome, login, senha, tipo) 
SELECT 'Administrador', 'admin', SHA2('admin123', 256), 'admin'
WHERE NOT EXISTS (SELECT 1 FROM usuarios WHERE login = 'admin');
