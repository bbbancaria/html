-- Tabela de vendas
CREATE TABLE IF NOT EXISTS vendas (
    id_venda VARCHAR(50) PRIMARY KEY,
    mesa VARCHAR(10),
    garcom VARCHAR(100),
    total DECIMAL(10,2),
    data_venda DATETIME,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de itens da venda
CREATE TABLE IF NOT EXISTS itens_venda (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_venda VARCHAR(50),
    id_produto INT,
    quantidade INT,
    preco_unitario DECIMAL(10,2),
    subtotal DECIMAL(10,2),
    FOREIGN KEY (id_venda) REFERENCES vendas(id_venda)
);

-- Tabela de pagamentos da venda
CREATE TABLE IF NOT EXISTS pagamentos_venda (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_venda VARCHAR(50),
    forma_pagamento VARCHAR(50),
    valor DECIMAL(10,2),
    FOREIGN KEY (id_venda) REFERENCES vendas(id_venda)
);
