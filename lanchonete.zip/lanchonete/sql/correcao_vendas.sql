-- Primeiro, vamos dropar as chaves estrangeiras existentes
SET FOREIGN_KEY_CHECKS = 0;

-- Renomeando a coluna antiga para evitar conflitos
ALTER TABLE vendas CHANGE venda_id id INT AUTO_INCREMENT;

-- Adicionando a coluna mesa_id se não existir
ALTER TABLE vendas ADD COLUMN IF NOT EXISTS mesa_id INT AFTER id;

-- Recriando a chave estrangeira
ALTER TABLE vendas ADD FOREIGN KEY (mesa_id) REFERENCES mesas(id);

-- Atualizando a referência na tabela pagamentos_venda
ALTER TABLE pagamentos_venda DROP FOREIGN KEY IF EXISTS pagamentos_venda_ibfk_1;
ALTER TABLE pagamentos_venda ADD FOREIGN KEY (venda_id) REFERENCES vendas(id);

SET FOREIGN_KEY_CHECKS = 1;
