<?php
require_once 'includes/conexao.php';

try {
    $stmt = $pdo->prepare("INSERT INTO garcons (nome) VALUES (:nome)");
    $stmt->execute(['nome' => 'Dane']);
    echo "Garçom Dane adicionado com sucesso!";
} catch (PDOException $e) {
    echo "Erro ao adicionar garçom: " . $e->getMessage();
}
?>
