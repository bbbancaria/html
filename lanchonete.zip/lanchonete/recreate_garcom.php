<?php
require_once 'includes/conexao.php';

try {
    // First delete the existing user
    $stmt = $pdo->prepare("DELETE FROM usuarios WHERE nome = :nome");
    $stmt->execute(['nome' => 'Dane']);
    
    if ($stmt->rowCount() > 0) {
        echo "Usuário existente removido.\n";
    }
    
    // Now insert the new user with correct tipo
    $stmt = $pdo->prepare("INSERT INTO usuarios (nome, login, senha, tipo, status) VALUES (:nome, :login, SHA2(:senha, 256), :tipo, :status)");
    $stmt->execute([
        'nome' => 'Dane',
        'login' => 'dane',
        'senha' => '123456',
        'tipo' => 'garcom',
        'status' => 'ativo'
    ]);
    
    if ($stmt->rowCount() > 0) {
        echo "Novo usuário inserido com sucesso!\n";
    }
    
    // Verify the insertion
    $stmt = $pdo->prepare("SELECT id, nome, tipo, status FROM usuarios WHERE nome = :nome");
    $stmt->execute(['nome' => 'Dane']);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario) {
        echo "\nStatus atual do usuário:\n";
        echo "ID: " . $usuario['id'] . "\n";
        echo "Nome: " . $usuario['nome'] . "\n";
        echo "Tipo: " . $usuario['tipo'] . "\n";
        echo "Status: " . $usuario['status'] . "\n";
    }
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
