<?php
require_once 'includes/conexao.php';

try {
    // First check if user already exists
    $stmt = $pdo->prepare("SELECT id FROM usuarios WHERE nome = :nome OR login = :login");
    $stmt->execute([
        'nome' => 'Dane',
        'login' => 'dane'
    ]);
    
    if ($stmt->fetch()) {
        echo "Usuário já existe no sistema.\n";
    } else {
        // Insert the new user
        $stmt = $pdo->prepare("INSERT INTO usuarios (nome, login, senha, tipo, status) VALUES (:nome, :login, SHA2(:senha, 256), 'garcom', 'ativo')");
        $stmt->execute([
            'nome' => 'Dane',
            'login' => 'dane',
            'senha' => '123456'
        ]);
        
        if ($stmt->rowCount() > 0) {
            echo "Garçom Dane adicionado com sucesso à tabela usuarios!\n";
            
            // Verify the insertion
            $stmt = $pdo->prepare("SELECT id, nome, tipo, status FROM usuarios WHERE nome = :nome");
            $stmt->execute(['nome' => 'Dane']);
            $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
            
            if ($usuario) {
                echo "Verificação: Usuário encontrado com ID: " . $usuario['id'] . 
                     ", Tipo: " . $usuario['tipo'] . 
                     ", Status: " . $usuario['status'] . "\n";
            }
        } else {
            echo "Erro: Nenhuma linha foi inserida.\n";
        }
    }
} catch (PDOException $e) {
    echo "Erro ao adicionar garçom: " . $e->getMessage() . "\n";
}
?>
