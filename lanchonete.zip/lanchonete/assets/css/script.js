// Validação do formulário de login
document.addEventListener("DOMContentLoaded", () => {
    const form = document.querySelector("form");
    const emailInput = document.querySelector("input[name='email']");
    const passwordInput = document.querySelector("input[name='senha']");

    form.addEventListener("submit", (event) => {
        let valid = true;
        let message = "";

        // Verifica se o email está vazio ou inválido
        if (!emailInput.value.trim() || !validateEmail(emailInput.value)) {
            valid = false;
            message = "Por favor, insira um email válido.";
        }

        // Verifica se a senha está vazia
        if (!passwordInput.value.trim()) {
            valid = false;
            message = "Por favor, insira sua senha.";
        }

        if (!valid) {
            event.preventDefault(); // Impede o envio do formulário
            alert(message); // Exibe mensagem de erro
        }
    });

    // Função para validar email
    function validateEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
});
