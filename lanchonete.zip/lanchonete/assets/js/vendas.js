// Verifica se jQuery está disponível
if (typeof jQuery === 'undefined') {
    console.error('jQuery não está carregado!');
} else {
    console.log('jQuery versão:', jQuery.fn.jquery);
}

// Verifica se Bootstrap está disponível
if (typeof bootstrap === 'undefined') {
    console.error('Bootstrap não está carregado!');
} else {
    console.log('Bootstrap disponível');
}

// Aguarda o documento estar pronto
$(document).ready(function() {
    console.log('Documento pronto');
    console.log('jQuery versão:', $.fn.jquery);
    
    // Verifica se o botão existe
    const btnConfirmar = $('#btnConfirmarPagamento');
    console.log('Botão encontrado:', btnConfirmar.length > 0);
    
    // Adiciona evento de clique diretamente
    btnConfirmar.on('click', function(e) {
        console.log('Clique direto no botão');
        handleConfirmarPagamento(e);
    });
    
    // Adiciona evento delegado
    $(document).on('click', '#btnConfirmarPagamento', function(e) {
        console.log('Clique delegado no botão');
        handleConfirmarPagamento(e);
    });
    
    console.log('Inicializando vendas.js'); // Debug

    // Variáveis globais
    let itens = [];
    let vendasEmAndamento = [];
    let vendaAtualId = null;
    
    // Inicialização do Select2 para o garçom
    $('#garcom').select2({
        theme: 'bootstrap-5',
        width: '100%',
        placeholder: 'Selecione o garçom...',
        allowClear: true
    });

    // Inicialização do Select2
    $('#produto').select2({
        theme: 'bootstrap-5',
        width: '100%',
        allowClear: true,
        placeholder: 'Buscar produto...',
        minimumInputLength: 2,
        ajax: {
            url: 'vendas.php?action=buscar_produtos',
            dataType: 'json',
            delay: 250,
            data: function(params) {
                return {
                    term: params.term,
                    action: 'buscar_produtos'
                };
            },
            processResults: function(data) {
                return {
                    results: data.results.map(function(item) {
                        return {
                            id: item.id,
                            text: item.text,
                            preco: item.preco,
                            nome: item.nome
                        };
                    })
                };
            },
            cache: true
        },
        language: {
            errorLoading: function() {
                return 'Erro ao carregar resultados';
            },
            inputTooShort: function() {
                return 'Digite pelo menos 2 caracteres para buscar';
            },
            noResults: function() {
                return 'Nenhum produto encontrado';
            },
            searching: function() {
                return 'Buscando...';
            }
        }
    }).on('select2:select', function(e) {
        console.log('Produto selecionado:', e.params.data);
    });

    // Event handler para o botão Adicionar Item
    $(document).on('click', '#btnAdicionarItem', function() {
        const produto = $('#produto').select2('data')[0];
        const quantidade = parseInt($('#quantidade').val());

        if (!produto || !produto.id) {
            alert('Selecione um produto');
            return;
        }

        if (isNaN(quantidade) || quantidade <= 0) {
            alert('Digite uma quantidade válida');
            return;
        }

        // Adiciona o item à lista
        itens.push({
            id: produto.id,
            nome: produto.text,
            quantidade: quantidade,
            preco: parseFloat(produto.preco || 0)
        });

        // Atualiza a interface
        atualizarTabelaItens();
        salvarVendaAtual();

        // Limpa os campos
        $('#produto').val(null).trigger('change');
        $('#quantidade').val(1);
    });

    // Função para atualizar a tabela de itens
    function atualizarTabelaItens() {
        const tbody = $('#tabelaItens tbody');
        tbody.empty();
        let total = 0;

        itens.forEach((item, index) => {
            const subtotal = item.quantidade * parseFloat(item.preco || 0);
            total += subtotal;

            tbody.append(`
                <tr>
                    <td>${item.nome}</td>
                    <td>${item.quantidade}</td>
                    <td>R$ ${subtotal.toFixed(2)}</td>
                    <td>
                        <button type="button" class="btn btn-danger btn-sm" onclick="removerItem(${index})">
                            <i class='bx bx-trash'></i>
                        </button>
                    </td>
                </tr>
            `);
        });

        // Atualiza o total
        $('#totalVenda').text(`R$ ${total.toFixed(2)}`);
    }

    // Função para remover item
    window.removerItem = function(index) {
        itens.splice(index, 1);
        atualizarTabelaItens();
        salvarVendaAtual();
    };

    // Funções de manipulação de vendas
    function salvarVendaAtual() {
        if (!vendaAtualId) {
            vendaAtualId = 'venda_' + new Date().getTime();
        }

        const garcom = $('#garcom').select2('data')[0];
        const mesa = $('#mesa').val();
        const pronto = $('#pedidoPronto').is(':checked');

        if (!garcom || !mesa) {
            console.warn('Dados incompletos para salvar venda');
            return;
        }

        const total = itens.reduce((acc, item) => acc + (item.quantidade * parseFloat(item.preco || 0)), 0);

        const vendaAtual = {
            id: vendaAtualId,
            garcom: garcom,
            mesa: mesa,
            itens: itens,
            total: total,
            pronto: pronto,
            finalizada: false,
            dataAtualizacao: new Date().toISOString()
        };

        const vendasSalvas = JSON.parse(localStorage.getItem('vendas') || '{}');
        vendasSalvas[vendaAtualId] = vendaAtual;
        localStorage.setItem('vendas', JSON.stringify(vendasSalvas));

        // Atualiza a exibição das vendas em andamento
        carregarVendasEmAndamento();
    }

    // Função para carregar vendas em andamento
    function carregarVendasEmAndamento() {
        const vendasContainer = $('#vendasEmAndamento');
        vendasContainer.empty();
        
        const vendasSalvas = JSON.parse(localStorage.getItem('vendas') || '{}');
        
        // Agrupar vendas por mesa
        const vendasPorMesa = {};
        Object.entries(vendasSalvas).forEach(([id, venda]) => {
            if (!venda.finalizada) {
                if (!vendasPorMesa[venda.mesa]) {
                    vendasPorMesa[venda.mesa] = [];
                }
                vendasPorMesa[venda.mesa].push({id, ...venda});
            }
        });

        // Criar cards para cada mesa
        Object.entries(vendasPorMesa).forEach(([mesa, vendas]) => {
            const mesaTitle = mesa === '0' ? 'Balcão' : `Mesa ${mesa}`;
            const mesaCard = $(`
                <div class="card mb-3">
                    <div class="card-header">
                        <h5 class="card-title mb-0">${mesaTitle}</h5>
                    </div>
                    <div class="card-body">
                        <div class="vendas-mesa"></div>
                        <button type="button" class="btn btn-success btn-finalizar-mesa" data-mesa="${mesa}">
                            Finalizar Todas as Vendas da ${mesaTitle}
                        </button>
                    </div>
                </div>
            `);

            const vendasMesaDiv = mesaCard.find('.vendas-mesa');
            vendas.forEach(venda => {
                const total = (venda.itens || []).reduce((acc, item) => {
                    return acc + (item.quantidade * parseFloat(item.preco || 0));
                }, 0);

                const vendaCard = $(`
                    <div class="card mb-2">
                        <div class="card-body">
                            <p class="card-text">Garçom: ${venda.garcom?.text || 'Não selecionado'}</p>
                            <p class="card-text">Total: R$ ${total.toFixed(2)}</p>
                            <p class="card-text">Status: ${venda.pronto ? 'Pronto/Entregue' : 'Em preparo'}</p>
                            <button type="button" class="btn btn-sm btn-primary btn-editar" data-venda-id="${venda.id}">
                                <i class='bx bx-edit'></i> Editar
                            </button>
                            <button type="button" class="btn btn-sm btn-success btn-finalizar-individual" data-venda-id="${venda.id}">
                                Finalizar Esta Venda
                            </button>
                        </div>
                    </div>
                `);
                vendasMesaDiv.append(vendaCard);
            });

            vendasContainer.append(mesaCard);
        });
    }

    // Função para finalizar uma venda específica
    function finalizarVenda(vendaId) {
        const vendasSalvas = JSON.parse(localStorage.getItem('vendas') || '{}');
        if (vendasSalvas[vendaId]) {
            vendasSalvas[vendaId].finalizada = true;
            localStorage.setItem('vendas', JSON.stringify(vendasSalvas));
            
            // Se a venda finalizada for a atual, limpa o formulário
            if (vendaId === vendaAtualId) {
                limparFormulario();
            }
            
            // Recarrega as vendas em andamento
            carregarVendasEmAndamento();
            return true;
        }
        return false;
    }

    // Event handler para finalizar venda individual
    $(document).on('click', '.btn-finalizar-individual', function(e) {
        e.preventDefault();
        const vendaId = $(this).data('venda-id');
        
        if (!vendaId) {
            console.error('ID da venda não encontrado');
            return;
        }

        mostrarConfirmacao('Tem certeza que deseja finalizar esta venda?', function() {
            if (finalizarVenda(vendaId)) {
                alert('Venda finalizada com sucesso!');
            } else {
                alert('Erro ao finalizar a venda. Por favor, tente novamente.');
            }
        });
    });

    // Event handler para finalizar todas as vendas de uma mesa
    $(document).on('click', '.btn-finalizar-mesa', function(e) {
        e.preventDefault();
        const mesa = $(this).data('mesa');
        const mesaTitle = mesa === '0' ? 'Balcão' : `Mesa ${mesa}`;
        
        mostrarConfirmacao(`Tem certeza que deseja finalizar todas as vendas do(a) ${mesaTitle}?`, function() {
            const vendasSalvas = JSON.parse(localStorage.getItem('vendas') || '{}');
            let alterado = false;
            
            Object.entries(vendasSalvas).forEach(([id, venda]) => {
                if (!venda.finalizada && venda.mesa.toString() === mesa.toString()) {
                    vendasSalvas[id].finalizada = true;
                    alterado = true;
                }
            });
            
            if (alterado) {
                localStorage.setItem('vendas', JSON.stringify(vendasSalvas));
                carregarVendasEmAndamento();
                limparFormulario();
                alert(`Todas as vendas do(a) ${mesaTitle} foram finalizadas com sucesso!`);
            } else {
                alert('Nenhuma venda foi encontrada para finalizar.');
            }
        });
    });

    // Handler para finalizar todas as vendas de uma mesa
    $(document).on('click', '.btn-finalizar-mesa', function() {
        const mesa = $(this).data('mesa');
        const mesaTitle = mesa === '0' ? 'Balcão' : `Mesa ${mesa}`;
        
        mostrarConfirmacao(`Tem certeza que deseja finalizar todas as vendas do(a) ${mesaTitle}?`, function() {
            const vendasSalvas = JSON.parse(localStorage.getItem('vendas') || '{}');
            let alterado = false;
            
            Object.entries(vendasSalvas).forEach(([id, venda]) => {
                if (!venda.finalizada && venda.mesa === mesa) {
                    vendasSalvas[id].finalizada = true;
                    alterado = true;
                }
            });
            
            if (alterado) {
                localStorage.setItem('vendas', JSON.stringify(vendasSalvas));
                carregarVendasEmAndamento();
                if (vendaAtualId && vendasSalvas[vendaAtualId]?.finalizada) {
                    limparFormulario();
                }
            }
        });
    });

    // Handler para finalizar venda individual
    $(document).on('click', '.btn-finalizar-individual', function() {
        const vendaId = $(this).data('venda-id');
        
        mostrarConfirmacao('Tem certeza que deseja finalizar esta venda?', function() {
            const vendasSalvas = JSON.parse(localStorage.getItem('vendas') || '{}');
            if (vendasSalvas[vendaId]) {
                vendasSalvas[vendaId].finalizada = true;
                localStorage.setItem('vendas', JSON.stringify(vendasSalvas));
                carregarVendasEmAndamento();
                if (vendaId === vendaAtualId) {
                    limparFormulario();
                }
            }
        });
    });

    // Event handler para o botão Nova Venda
    $(document).on('click', '[data-action="nova-venda"]', function() {
        criarNovaVenda();
    });

    // Carregar vendas em andamento ao iniciar
    $(document).ready(function() {
        carregarVendasEmAndamento();
    });

    // Atualizar vendas em andamento após finalizar uma venda
    function atualizarVendasEmAndamento() {
        carregarVendasEmAndamento();
    }

    // Event Handlers para finalização de venda
    $(document).on('click', '[data-action="finalizar-venda"]', function() {
        console.log('Iniciando finalização da venda');
        console.log('ID da venda:', vendaAtualId);
        console.log('Itens:', itens);
        console.log('Mesa:', $('#mesa').val());
        console.log('Garçom:', $('#garcom').val());
        
        if (!vendaAtualId) {
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: 'Nenhuma venda em andamento'
            });
            return;
        }

        const pedidoPronto = $('#pedidoPronto').is(':checked');
        console.log('Estado do checkbox:', pedidoPronto);

        if (!pedidoPronto) {
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: 'Marque o pedido como pronto antes de finalizar a venda'
            });
            return;
        }

        if (itens.length === 0) {
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: 'Adicione pelo menos um item à venda'
            });
            return;
        }

        // Abre o modal de pagamento
        const modalPagamento = new bootstrap.Modal(document.getElementById('modalPagamento'));
        modalPagamento.show();
        
        // Atualiza o valor total no modal
        const total = calcularTotal();
        console.log('Total da venda:', total);
        $('#modalTotal').text(`R$ ${total.toFixed(2)}`);
        $('#valorRestante').text(`R$ ${total.toFixed(2)}`);
    });

    // Manipulador do botão de confirmar pagamento
    $(document).on('click', '#btnConfirmarPagamento', function(e) {
        e.preventDefault();
        console.log('Botão confirmar pagamento clicado');
        
        const pagamentos = [];
        let valorTotal = 0;

        // Coleta todas as formas de pagamento
        $('[id^=forma_pagamento_]').each(function() {
            const num = $(this).attr('id').match(/\d+/)[0];
            const containerVisible = $(`#forma_pagamento_${num}_container`).is(':visible') || num === '1';
            
            if (containerVisible) {
                const forma = $(this).val();
                const valor = parseFloat($(`#valor_pagamento_${num}`).val().replace(',', '.')) || 0;
                
                if (forma && valor > 0) {
                    pagamentos.push({ forma, valor });
                    valorTotal += valor;
                }
            }
        });

        console.log('Formas de pagamento:', pagamentos);
        console.log('Valor total dos pagamentos:', valorTotal);

        // Verifica se pelo menos uma forma de pagamento foi selecionada
        if (pagamentos.length === 0) {
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: 'Selecione pelo menos uma forma de pagamento e informe o valor'
            });
            return;
        }

        // Verifica se o valor total dos pagamentos corresponde ao valor da venda
        const totalVenda = calcularTotal();
        console.log('Total da venda:', totalVenda);
        
        if (Math.abs(valorTotal - totalVenda) > 0.01) {
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: `O valor total dos pagamentos (R$ ${valorTotal.toFixed(2)}) deve ser igual ao valor da venda (R$ ${totalVenda.toFixed(2)})`
            });
            return;
        }

        // Prepara os dados da venda
        const dadosVenda = {
            mesa: $('#mesa').val(),
            garcom: $('#garcom').val(),
            itens: itens.map(item => ({
                id: item.id,
                quantidade: item.quantidade,
                preco: item.preco
            })),
            pagamentos: pagamentos,
            total: totalVenda
        };

        console.log('Dados da venda:', dadosVenda);
        console.log('URL da API:', window.location.origin + '/lanchonete/api/finalizar_venda.php');

        // Envia para o servidor
        fetch('/lanchonete/api/finalizar_venda.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(dadosVenda),
            credentials: 'include'
        })
        .then(response => {
            console.log('Status da resposta:', response.status);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Resposta do servidor:', data);
            if (data.success) {
                // Remove a venda da lista de vendas em andamento
                vendasEmAndamento = vendasEmAndamento.filter(v => v.id !== vendaAtualId);
                localStorage.setItem('vendasEmAndamento', JSON.stringify(vendasEmAndamento));

                // Limpa o formulário
                vendaAtualId = null;
                itens = [];
                $('#mesa').val('');
                $('#garcom').val('');
                $('#produto').val(null).trigger('change');
                $('#quantidade').val(1);
                atualizarTabelaItens();

                // Fecha o modal e mostra mensagem de sucesso
                $('#modalPagamento').modal('hide');
                Swal.fire({
                    icon: 'success',
                    title: 'Sucesso!',
                    text: 'Venda finalizada com sucesso',
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    // Recarrega a página após finalizar
                    window.location.reload();
                });
            } else {
                throw new Error(data.message || 'Erro desconhecido');
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: error.message || 'Ocorreu um erro ao finalizar a venda'
            });
        });
    });

    // Função para deletar uma venda
    function deletarVenda(vendaId) {
        Swal.fire({
            title: 'Tem certeza?',
            text: "Deseja realmente cancelar esta venda?",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Sim, cancelar!',
            cancelButtonText: 'Não'
        }).then((result) => {
            if (result.isConfirmed) {
                $.ajax({
                    url: 'api/deletar_venda.php',
                    type: 'POST',
                    data: {
                        venda_id: vendaId
                    },
                    success: function(response) {
                        try {
                            const data = JSON.parse(response);
                            if (data.status === 'success') {
                                Swal.fire(
                                    'Cancelada!',
                                    'A venda foi cancelada com sucesso.',
                                    'success'
                                );
                                carregarMesasEmAndamento();
                            } else {
                                Swal.fire(
                                    'Erro!',
                                    data.message || 'Erro ao cancelar venda'
                                );
                            }
                        } catch (e) {
                            console.error('Erro ao processar resposta:', e);
                            Swal.fire(
                                'Erro!',
                                'Erro ao processar resposta do servidor'
                            );
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Erro na requisição:', error);
                        Swal.fire(
                            'Erro!',
                            'Erro ao comunicar com o servidor'
                        );
                    }
                });
            }
        });
    }

    // Atualizar a função que exibe as mesas
    function carregarMesasEmAndamento() {
        $.ajax({
            url: 'api/listar_mesas.php',
            type: 'GET',
            success: function(response) {
                try {
                    const data = JSON.parse(response);
                    const container = $('#mesas-container');
                    container.empty();

                    data.forEach(mesa => {
                        // Verifica se a mesa está em preparo
                        const emPreparo = true; // Por enquanto vamos assumir que todas estão em preparo
                        
                        const card = `
                            <div class="col-md-3 mb-4">
                                <div class="card">
                                    <div class="card-header d-flex justify-content-between align-items-center">
                                        <h5 class="mb-0">Mesa ${mesa.numero || ''}</h5>
                                        <span class="badge bg-warning">Em preparo</span>
                                    </div>
                                    <div class="card-body">
                                        <p class="card-text">Garçom: ${mesa.garcom || 'Não definido'}</p>
                                        <p class="card-text">Total: ${formatarMoeda((mesa.total * 100).toString())}</p>
                                        ${mesa.produtos ? `
                                            <div class="produtos-lista">
                                                ${mesa.produtos}
                                            </div>
                                        ` : ''}
                                        <div class="d-flex justify-content-between mt-2">
                                            <button class="btn btn-primary btn-sm" onclick="editarVenda(${mesa.id})">
                                                <i class="fas fa-edit"></i> Editar
                                            </button>
                                            <button class="btn btn-danger btn-sm" onclick="deletarVenda(${mesa.id})">
                                                <i class="fas fa-trash"></i> Deletar
                                            </button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        `;
                        container.append(card);
                    });
                } catch (e) {
                    console.error('Erro ao processar dados das mesas:', e);
                    Swal.fire(
                        'Erro!',
                        'Erro ao carregar mesas'
                    );
                }
            },
            error: function(xhr, status, error) {
                console.error('Erro ao carregar mesas:', error);
                Swal.fire(
                    'Erro!',
                    'Erro ao comunicar com o servidor'
                );
            }
        });
    }

    // Inicialização quando o documento estiver pronto
    $(document).ready(function() {
        // Carrega as mesas em andamento ao iniciar
        carregarMesasEmAndamento();
        
        // Recarrega as mesas a cada 30 segundos
        setInterval(carregarMesasEmAndamento, 30000);
    });

    // Função para abrir modal de nova mesa
    function novaMesa() {
        $('#numeroMesa').val('');
        $('#modalNovaMesa').modal('show');
    }

    // Função para salvar nova mesa
    function salvarNovaMesa() {
        const numeroMesa = $('#numeroMesa').val();
        
        if (!numeroMesa) {
            Swal.fire('Erro', 'Por favor, informe o número da mesa', 'error');
            return;
        }

        $.ajax({
            url: 'api/nova_mesa.php',
            type: 'POST',
            data: {
                mesa: numeroMesa
            },
            success: function(response) {
                try {
                    const data = JSON.parse(response);
                    if (data.status === 'success') {
                        $('#modalNovaMesa').modal('hide');
                        Swal.fire(
                            'Sucesso!',
                            'Mesa criada com sucesso',
                            'success'
                        );
                        carregarMesasEmAndamento();
                    } else {
                        Swal.fire(
                            'Erro!',
                            data.message || 'Erro ao criar mesa'
                        );
                    }
                } catch (e) {
                    console.error('Erro ao processar resposta:', e);
                    Swal.fire(
                        'Erro!',
                        'Erro ao processar resposta do servidor'
                    );
                }
            },
            error: function(xhr, status, error) {
                console.error('Erro na requisição:', error);
                Swal.fire(
                    'Erro!',
                    'Erro ao comunicar com o servidor'
                );
            }
        });
    }

    // Funções auxiliares
    function adicionarItem(produto, quantidade) {
        itens.push({
            id: produto.id,
            nome: produto.nome,
            preco: produto.preco,
            quantidade: quantidade
        });

        atualizarTabelaItens();
        salvarVendaAtual();
    }

    function calcularTotal() {
        return itens.reduce((acc, item) => acc + (item.quantidade * parseFloat(item.preco || 0)), 0);
    }

    function atualizarTotal() {
        const total = calcularTotal();
        $('#totalVenda').text(`R$ ${total.toFixed(2)}`);
    }

    // Inicialização dos eventos do modal de pagamento
    $('#modalPagamento').on('show.bs.modal', function() {
        const total = calcularTotal();
        $('#modalTotal').text(`R$ ${total.toFixed(2)}`);
        $('#valorRestante').text(`R$ ${total.toFixed(2)}`);
        
        // Limpa os campos de pagamento
        $('[id^=forma_pagamento_]').val('');
        $('[id^=valor_pagamento_]').val('');
        
        // Mostra apenas a primeira forma de pagamento
        $('#forma_pagamento_1_container').show();
        $('#forma_pagamento_2_container, #forma_pagamento_3_container, #forma_pagamento_4_container').hide();
        
        // Atualiza botões de adicionar/remover formas de pagamento
        $('#btnAdicionarFormaPagamento').show();
        $('#btnRemoverFormaPagamento').hide();
    });

    // Evento para adicionar forma de pagamento
    $('#btnAdicionarFormaPagamento').on('click', function() {
        const containers = $('[id^=forma_pagamento_][id$=_container]');
        const visiveis = containers.filter(':visible').length;
        
        if (visiveis < 4) {
            $(`#forma_pagamento_${visiveis + 1}_container`).slideDown();
            if (visiveis + 1 === 4) {
                $(this).hide();
            }
            $('#btnRemoverFormaPagamento').show();
        }
        
        atualizarValorRestante();
    });

    // Evento para remover forma de pagamento
    $('#btnRemoverFormaPagamento').on('click', function() {
        const containers = $('[id^=forma_pagamento_][id$=_container]');
        const visiveis = containers.filter(':visible').length;
        
        if (visiveis > 1) {
            const ultimoContainer = $(`#forma_pagamento_${visiveis}_container`);
            ultimoContainer.slideUp();
            ultimoContainer.find('select, input').val('');
            
            if (visiveis - 1 === 1) {
                $(this).hide();
            }
            $('#btnAdicionarFormaPagamento').show();
            
            atualizarValorRestante();
        }
    });

    // Função para formatar valor em moeda brasileira
    function formatarMoeda(valor) {
        valor = valor.replace(/\D/g, '');
        valor = (parseInt(valor) / 100).toFixed(2);
        valor = valor.replace('.', ',');
        valor = valor.replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1.');
        return `R$ ${valor}`;
    }

    // Evento para formatar valores monetários durante a digitação
    $(document).on('input', '[id^=valor_pagamento_]', function() {
        const total = calcularTotal();
        let valor = $(this).val().replace(/\D/g, '');
        
        if (!valor) {
            $(this).val('');
            atualizarValorRestante();
            return;
        }

        // Converte para número e formata
        const valorNumerico = parseInt(valor) / 100;
        
        // Se o valor for maior que o total, ajusta para o total
        if (valorNumerico > total) {
            valor = (total * 100).toFixed(0);
        }
        
        $(this).val(formatarMoeda(valor));
        atualizarValorRestante();
    });

    // Função para atualizar o valor restante
    function atualizarValorRestante() {
        const total = calcularTotal();
        let valorPago = 0;
        
        $('[id^=valor_pagamento_]:visible').each(function() {
            const valor = $(this).val().replace(/\D/g, '');
            valorPago += parseInt(valor) / 100;
        });
        
        const restante = Math.max(0, total - valorPago);
        $('#valorRestante').text(formatarMoeda((restante * 100).toFixed(0)));
        
        // Desabilita o botão de confirmar se o valor pago for diferente do total
        const btnConfirmar = $('#btnConfirmarPagamento');
        btnConfirmar.prop('disabled', Math.abs(total - valorPago) > 0.01);
    }

    // Inicializa uma nova venda
    $('#btnNovaVenda').on('click', function() {
        vendaAtualId = Date.now(); // Gera um ID único baseado no timestamp
        itens = [];
        $('#mesa').val('');
        $('#garcom').val('');
        $('#produto').val(null).trigger('change');
        $('#quantidade').val(1);
        atualizarTabelaItens();
    });

    // Quando selecionar garçom ou mesa, salva a venda
    $('#garcom, #mesa').on('change', function() {
        if (vendaAtualId) {
            salvarVendaAtual();
        } else {
            vendaAtualId = Date.now();
            salvarVendaAtual();
        }
    });

    // Carrega uma venda existente
    window.carregarVenda = function(id) {
        const venda = vendasEmAndamento.find(v => v.id === id);
        if (venda) {
            vendaAtualId = venda.id;
            itens = [...venda.itens];
            $('#mesa').val(venda.mesa);
            $('#garcom').val(venda.garcom);
            atualizarTabelaItens();
            
            // Atualiza o estado do pedido
            if (venda.pronto) {
                $('#pedidoPronto').prop('checked', true);
            }
        }
    };

    // Função para lidar com o pagamento
    function handleConfirmarPagamento(e) {
        e.preventDefault();
        console.log('Função handleConfirmarPagamento chamada');
        
        const pagamentos = [];
        let valorTotal = 0;

        // Coleta todas as formas de pagamento visíveis
        $('[id^=forma_pagamento_][id$=_container]:visible').each(function() {
            const num = $(this).attr('id').match(/\d+/)[0];
            const forma = $(`#forma_pagamento_${num}`).val();
            const valor = parseFloat($(`#valor_pagamento_${num}`).val().replace(',', '.')) || 0;
            
            if (forma && valor > 0) {
                pagamentos.push({ forma, valor });
                valorTotal += valor;
            }
        });

        console.log('Formas de pagamento:', pagamentos);
        console.log('Valor total dos pagamentos:', valorTotal);

        // Verifica se o valor total dos pagamentos corresponde ao valor da venda
        const totalVenda = calcularTotal();
        console.log('Total da venda:', totalVenda);
        
        if (Math.abs(valorTotal - totalVenda) > 0.01) {
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: `O valor total dos pagamentos (R$ ${valorTotal.toFixed(2)}) deve ser igual ao valor da venda (R$ ${totalVenda.toFixed(2)})`
            });
            return;
        }

        // Prepara os dados da venda
        const dadosVenda = {
            mesa: $('#mesa').val(),
            garcom: $('#garcom').val(),
            itens: itens.map(item => ({
                id: item.id,
                quantidade: item.quantidade,
                preco: item.preco
            })),
            pagamentos: pagamentos,
            total: totalVenda
        };

        console.log('Dados da venda:', dadosVenda);

        // Mostra loading
        Swal.fire({
            title: 'Processando...',
            text: 'Finalizando a venda',
            allowOutsideClick: false,
            allowEscapeKey: false,
            showConfirmButton: false,
            didOpen: () => {
                Swal.showLoading();
            }
        });

        // Envia para o servidor usando fetch
        fetch('/lanchonete/api/finalizar_venda.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Accept': 'application/json'
            },
            body: JSON.stringify(dadosVenda),
            credentials: 'include'
        })
        .then(response => {
            console.log('Status da resposta:', response.status);
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            return response.json();
        })
        .then(data => {
            console.log('Resposta do servidor:', data);
            if (data.success) {
                // Remove a venda da lista de vendas em andamento
                vendasEmAndamento = vendasEmAndamento.filter(v => v.id !== vendaAtualId);
                localStorage.setItem('vendasEmAndamento', JSON.stringify(vendasEmAndamento));

                // Limpa o formulário
                vendaAtualId = null;
                itens = [];
                $('#mesa').val('');
                $('#garcom').val('');
                $('#produto').val(null).trigger('change');
                $('#quantidade').val(1);
                atualizarTabelaItens();

                // Fecha o modal e mostra mensagem de sucesso
                $('#modalPagamento').modal('hide');
                Swal.fire({
                    icon: 'success',
                    title: 'Sucesso!',
                    text: 'Venda finalizada com sucesso',
                    showConfirmButton: false,
                    timer: 2000
                }).then(() => {
                    // Recarrega a página após finalizar
                    window.location.reload();
                });
            } else {
                throw new Error(data.message || 'Erro desconhecido');
            }
        })
        .catch(error => {
            console.error('Erro:', error);
            Swal.fire({
                icon: 'error',
                title: 'Erro',
                text: error.message || 'Ocorreu um erro ao finalizar a venda'
            });
        });
    }

    // Função para mostrar confirmação
    function mostrarConfirmacao(mensagem, onConfirm) {
        const modal = new bootstrap.Modal(document.getElementById('confirmacaoModal'));
        $('#confirmacaoMensagem').text(mensagem);
        
        $('#btnConfirmar').off('click').on('click', function() {
            modal.hide();
            onConfirm();
        });
        
        modal.show();
    }

    // Handler para finalizar venda
    // $(document).on('click', '[data-action="finalizar-venda"]', function(e) {
    //     e.preventDefault();
    //     if (!vendaAtualId || itens.length === 0) {
    //         alert('Não há itens na venda para finalizar.');
    //         return;
    //     }

    //     mostrarConfirmacao('Tem certeza que deseja finalizar esta venda?', function() {
    //         const vendasSalvas = JSON.parse(localStorage.getItem('vendas') || '{}');
    //         if (vendasSalvas[vendaAtualId]) {
    //             vendasSalvas[vendaAtualId].finalizada = true;
    //             localStorage.setItem('vendas', JSON.stringify(vendasSalvas));
    //             limparFormulario();
    //             carregarVendasEmAndamento();
    //         }
    //     });
    // });

    // Handler para checkbox de pedido pronto
    $('#pedidoPronto').on('change', function(e) {
        e.preventDefault();
        const isChecked = $(this).prop('checked');
        $(this).prop('checked', !isChecked); // Reverte temporariamente

        const mensagem = isChecked ? 
            'Deseja marcar este pedido como pronto/entregue?' : 
            'Deseja desmarcar este pedido como não pronto?';

        mostrarConfirmacao(mensagem, function() {
            const vendasSalvas = JSON.parse(localStorage.getItem('vendas') || '{}');
            if (vendasSalvas[vendaAtualId]) {
                vendasSalvas[vendaAtualId].pronto = isChecked;
                localStorage.setItem('vendas', JSON.stringify(vendasSalvas));
                $('#pedidoPronto').prop('checked', isChecked);
                carregarVendasEmAndamento();
            }
        });
    });
});