<?php
require_once 'includes/conexao.php';

try {
    // Get table structure
    $stmt = $pdo->query("DESCRIBE usuarios");
    $columns = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo "Estrutura da tabela usuarios:\n";
    foreach ($columns as $column) {
        echo json_encode($column, JSON_PRETTY_PRINT) . "\n";
    }
    
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
