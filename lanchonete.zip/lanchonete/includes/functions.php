<?php
if (!function_exists('logError')) {
    function logError($message, $type = 'ERROR', $file = 'system.log') {
        try {
            $logDir = __DIR__ . '/../logs';
            if (!file_exists($logDir)) {
                mkdir($logDir, 0777, true);
            }
            
            $logFile = $logDir . '/' . $file;
            if (!file_exists($logFile)) {
                touch($logFile);
            }

            $date = date('Y-m-d H:i:s');
            $logMessage = "[$date] [$type] $message" . PHP_EOL;
            error_log($logMessage, 3, $logFile);
        } catch (Exception $e) {
            error_log("Erro ao escrever log: " . $e->getMessage());
        }
    }
}
