<?php
session_start();

// Configuração temporária para desenvolvimento
if (!isset($_SESSION['usuario_id'])) {
    $_SESSION['usuario_id'] = 1;
    $_SESSION['usuario_nome'] = 'Admin';
    $_SESSION['usuario_nivel'] = 'admin';
}