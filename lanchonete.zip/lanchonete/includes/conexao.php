<?php
// Inicia a sessão se ainda não foi iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Ativa exibição de erros em desenvolvimento
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Inclui arquivo de funções
require_once __DIR__ . '/functions.php';

try {
    // Configurações do banco de dados
    $host = 'localhost';
    $dbname = 'erpmon62_sistema_lanchonete';
    $username = 'root';
    $password = '';
    
    // String de conexão PDO
    $dsn = "mysql:host=$host;dbname=$dbname;charset=utf8mb4";
    
    // Opções do PDO
    $options = [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES => false,
        PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci"
    ];

    // Tenta estabelecer a conexão
    $pdo = new PDO($dsn, $username, $password, $options);
    
    // Configura timezone para o MySQL
    $pdo->exec("SET time_zone = '-03:00'"); // Configura timezone para GMT-3 (São Paulo)
    
    // Verifica se a tabela usuarios existe
    $stmt = $pdo->query("SHOW TABLES LIKE 'usuarios'");
    if ($stmt->rowCount() == 0) {
        // Cria a tabela usuarios
        $sql = "CREATE TABLE IF NOT EXISTS usuarios (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(100) NOT NULL,
            login VARCHAR(50) NOT NULL UNIQUE,
            senha VARCHAR(64) NOT NULL,
            tipo ENUM('admin', 'funcionario') NOT NULL DEFAULT 'funcionario',
            status ENUM('ativo', 'inativo') DEFAULT 'ativo',
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
            updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;";
        
        $pdo->exec($sql);
        
        // Insere o usuário admin padrão
        $sql = "INSERT INTO usuarios (nome, login, senha, tipo) 
                SELECT 'Administrador', 'admin', SHA2('admin123', 256), 'admin'
                WHERE NOT EXISTS (SELECT 1 FROM usuarios WHERE login = 'admin');";
        
        $pdo->exec($sql);
        logError("Tabela usuarios criada e usuário admin inserido", "INFO");
    }
    
} catch (PDOException $e) {
    logError("Erro PDO: " . $e->getMessage());
    
    if (strpos($e->getMessage(), "Unknown column 'login'") !== false) {
        // Se o erro for específico da coluna login, tenta criar a tabela
        try {
            $pdo->exec("DROP TABLE IF EXISTS usuarios;");
            $pdo->exec("CREATE TABLE usuarios (
                id INT AUTO_INCREMENT PRIMARY KEY,
                nome VARCHAR(100) NOT NULL,
                login VARCHAR(50) NOT NULL UNIQUE,
                senha VARCHAR(64) NOT NULL,
                tipo ENUM('admin', 'funcionario') NOT NULL DEFAULT 'funcionario',
                status ENUM('ativo', 'inativo') DEFAULT 'ativo',
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
            );");
            
            // Insere o usuário admin padrão
            $pdo->exec("INSERT INTO usuarios (nome, login, senha, tipo) 
                       VALUES ('Administrador', 'admin', SHA2('admin123', 256), 'admin');");
                       
            // Reconecta ao banco
            $pdo = new PDO($dsn, $username, $password, $options);
            logError("Tabela usuarios recriada com sucesso", "INFO");
            
        } catch (Exception $inner_e) {
            logError("Erro ao criar tabela usuarios: " . $inner_e->getMessage());
            die("Erro ao criar tabela usuarios: " . $inner_e->getMessage());
        }
    } else {
        // Para outros erros, exibe mensagem amigável
        if (!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && 
            strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
            header('Content-Type: application/json');
            echo json_encode(['status' => 'error', 'message' => 'Erro de conexão com o banco de dados']);
        } else {
            echo "<h1>Erro de Conexão</h1>";
            echo "<p>Não foi possível conectar ao banco de dados.</p>";
            echo "<p>Por favor, tente novamente mais tarde ou contate o suporte.</p>";
        }
        exit;
    }
}

// Configura timezone do PHP
date_default_timezone_set('America/Sao_Paulo');

// Log de sucesso
logError("Conexão estabelecida com sucesso", "INFO");
