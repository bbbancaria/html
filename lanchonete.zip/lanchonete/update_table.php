<?php
require_once 'includes/conexao.php';

try {
    // Modify the tipo column to include 'garcom'
    $stmt = $pdo->query("ALTER TABLE usuarios MODIFY COLUMN tipo ENUM('admin', 'funcionario', 'garcom') NOT NULL DEFAULT 'funcionario'");
    echo "Tabela atualizada com sucesso!\n";
    
    // Now try to set Dane as garçom
    $stmt = $pdo->prepare("UPDATE usuarios SET tipo = 'garcom' WHERE nome = :nome");
    $stmt->execute(['nome' => 'Dane']);
    
    if ($stmt->rowCount() > 0) {
        echo "Usuário Dane atualizado para garçom!\n";
    }
    
    // Verify the update
    $stmt = $pdo->prepare("SELECT id, nome, tipo, status FROM usuarios WHERE nome = :nome");
    $stmt->execute(['nome' => 'Dane']);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario) {
        echo "\nStatus atual do usuário:\n";
        echo "ID: " . $usuario['id'] . "\n";
        echo "Nome: " . $usuario['nome'] . "\n";
        echo "Tipo: " . $usuario['tipo'] . "\n";
        echo "Status: " . $usuario['status'] . "\n";
    }
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
