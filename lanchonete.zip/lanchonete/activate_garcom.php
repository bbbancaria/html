<?php
require_once 'includes/conexao.php';

try {
    // Update any existing garçom to be active
    $stmt = $pdo->prepare("UPDATE usuarios SET status = 'ativo', tipo = 'garcom' WHERE nome = :nome");
    $stmt->execute(['nome' => 'Dane']);
    
    if ($stmt->rowCount() > 0) {
        echo "Garçom Dane atualizado com sucesso!\n";
    } else {
        echo "Nenhuma atualização necessária para o garçom Dane.\n";
    }
    
    // Verify current status
    $stmt = $pdo->prepare("SELECT id, nome, tipo, status FROM usuarios WHERE nome = :nome");
    $stmt->execute(['nome' => 'Dane']);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($usuario) {
        echo "\nStatus atual do usuário:\n";
        echo "ID: " . $usuario['id'] . "\n";
        echo "Nome: " . $usuario['nome'] . "\n";
        echo "Tipo: " . $usuario['tipo'] . "\n";
        echo "Status: " . $usuario['status'] . "\n";
    } else {
        echo "\nUsuário não encontrado na tabela usuarios.\n";
    }
} catch (PDOException $e) {
    echo "Erro: " . $e->getMessage();
}
?>
