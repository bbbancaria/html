-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Tempo de geração: 16/12/2024 às 19:34
-- Versão do servidor: 5.7.23-23
-- Versão do PHP: 8.1.31

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `erpmon62_sistema_lanchonete`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `financeiro`
--

CREATE TABLE `financeiro` (
  `id` int(11) NOT NULL,
  `descricao` varchar(255) NOT NULL,
  `valor` decimal(10,2) NOT NULL,
  `tipo` enum('Entrada','Saída') NOT NULL,
  `data_movimentacao` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `financeiro`
--

INSERT INTO `financeiro` (`id`, `descricao`, `valor`, `tipo`, `data_movimentacao`) VALUES
(1, 'Venda de Coxinhas', 10.00, 'Entrada', '2024-11-23 15:28:50'),
(2, 'Compra de Estoque', 50.00, 'Saída', '2024-11-23 15:28:50');

-- --------------------------------------------------------

--
-- Estrutura para tabela `funcionarios`
--

CREATE TABLE `funcionarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `valor_hora` decimal(10,2) DEFAULT '0.00',
  `senha` varchar(255) NOT NULL,
  `cargo` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `funcionarios`
--

INSERT INTO `funcionarios` (`id`, `nome`, `valor_hora`, `senha`, `cargo`) VALUES
(1, 'João Silva', 10.00, '', 'garcom'),
(2, 'Maria Oliveira', 12.50, '', 'garcom');

-- --------------------------------------------------------

--
-- Estrutura para tabela `garcons`
--

CREATE TABLE `garcons` (
  `id` int(11) NOT NULL,
  `nome` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `garcons`
--

INSERT INTO `garcons` (`id`, `nome`) VALUES
(1, 'João Silva'),
(2, 'Maria Oliveira'),
(3, 'Carlos Souza');

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_pedidos`
--

CREATE TABLE `itens_pedidos` (
  `id` int(11) NOT NULL,
  `pedido_id` int(11) NOT NULL,
  `produto_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura para tabela `itens_venda`
--

CREATE TABLE `itens_venda` (
  `id` int(11) NOT NULL,
  `venda_id` int(11) NOT NULL,
  `produto_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `preco_unitario` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `itens_venda`
--

INSERT INTO `itens_venda` (`id`, `venda_id`, `produto_id`, `quantidade`, `preco_unitario`, `subtotal`) VALUES
(1, 1, 2, 1, 3.00, 3.00),
(2, 2, 9, 1, 6.50, 6.50),
(3, 2, 10, 1, 2.50, 2.50),
(4, 3, 2, 1, 3.00, 3.00),
(5, 16, 18, 1, 14.00, 14.00),
(6, 17, 78, 3, 10.00, 30.00),
(7, 18, 31, 1, 13.00, 13.00),
(8, 19, 34, 1, 13.00, 13.00),
(9, 20, 86, 1, 2.50, 0.00),
(10, 21, 16, 1, 15.00, 0.00),
(11, 22, 34, 1, 13.00, 0.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `log_acessos`
--

CREATE TABLE `log_acessos` (
  `id` int(11) NOT NULL,
  `usuario_id` int(11) DEFAULT NULL,
  `ip` varchar(45) NOT NULL,
  `acao` varchar(50) NOT NULL,
  `data_acesso` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura para tabela `mesas`
--

CREATE TABLE `mesas` (
  `id` int(11) NOT NULL,
  `numero` varchar(10) NOT NULL,
  `status` enum('livre','ocupada','reservada') DEFAULT 'livre',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura para tabela `pagamentos_venda`
--

CREATE TABLE `pagamentos_venda` (
  `id` int(11) NOT NULL,
  `venda_id` int(11) NOT NULL,
  `forma_pagamento` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `valor` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Despejando dados para a tabela `pagamentos_venda`
--

INSERT INTO `pagamentos_venda` (`id`, `venda_id`, `forma_pagamento`, `valor`) VALUES
(1, 20, 'dinheiro', 2.50),
(2, 21, 'dinheiro', 10.00),
(3, 21, 'pix', 5.00),
(4, 22, 'dinheiro', 12.00),
(5, 22, 'pix', 1.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `pedidos`
--

CREATE TABLE `pedidos` (
  `id` int(11) NOT NULL,
  `mesa` int(11) NOT NULL,
  `produto_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `garcom` varchar(100) NOT NULL,
  `data_pedido` datetime DEFAULT CURRENT_TIMESTAMP,
  `status` enum('Pendente','Finalizado') DEFAULT 'Pendente',
  `garcom_id` int(11) DEFAULT NULL,
  `hora_pedido` datetime NOT NULL,
  `data_hora` datetime DEFAULT CURRENT_TIMESTAMP,
  `itens` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura para tabela `ponto`
--

CREATE TABLE `ponto` (
  `id` int(11) NOT NULL,
  `funcionario_id` int(11) NOT NULL,
  `entrada` datetime NOT NULL,
  `saida` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `ponto`
--

INSERT INTO `ponto` (`id`, `funcionario_id`, `entrada`, `saida`) VALUES
(1, 1, '2024-11-23 20:20:00', '2024-11-23 20:20:00');

-- --------------------------------------------------------

--
-- Estrutura para tabela `produtos`
--

CREATE TABLE `produtos` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `preco` decimal(10,2) NOT NULL,
  `estoque` int(11) NOT NULL DEFAULT '0',
  `dona` varchar(50) NOT NULL,
  `status` varchar(20) DEFAULT 'ativo'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `produtos`
--

INSERT INTO `produtos` (`id`, `nome`, `preco`, `estoque`, `dona`, `status`) VALUES
(1, 'Tapioca - DELÍCIA - Queijo, coco e manteiga', 14.00, 1000, 'Silvania', 'ativo'),
(2, 'Tapioca - PÉ DE SOGRA - Queijo, ovo e frango', 14.00, 1000, 'Silvania', 'ativo'),
(3, 'Tapioca - RAÇUDO - Queijo, ovo, carne de sol e cream cheese - 4', 15.00, 1000, 'Silvania', 'ativo'),
(4, 'Tapioca - SERTANEJA - Queijo, ovo e carne de sol', 14.00, 1000, 'Silvania', 'ativo'),
(5, 'Tapioca - JOÃO GRILO - Queijo, ovo, calabresa e cream cheese', 15.00, 1000, 'Silvania', 'ativo'),
(6, 'Tapioca - CAIPIRA - Queijo, ovo e calabresa', 14.00, 1000, 'Silvania', 'ativo'),
(7, 'Tapioca - SEVERINA NORDESTINA - Queijo, carne de sol, frango e cream cheese', 15.00, 1000, 'Silvania', 'ativo'),
(8, 'Tapioca - LAMPIÃO - Queijo, frango e carne de sol', 14.00, 1000, 'Silvania', 'ativo'),
(9, 'Tapioca - CAATINGA - Queijo, carne de sol, frango e ovo', 15.00, 1000, 'Silvania', 'ativo'),
(10, 'Tapioca - ROÇEIRA - Queijo, frango e calabresa', 14.00, 1000, 'Silvania', 'ativo'),
(11, 'Tapioca - RISCA FACA - Queijo, frango e catupiry', 14.00, 1000, 'Silvania', 'ativo'),
(12, 'Tapioca - DONA FLOR - Queijo, frango e milho', 14.00, 1000, 'Silvania', 'ativo'),
(13, 'VIXE MARIA - Queijo, frango, milho e cream cheese', 15.00, 1000, 'Silvania', 'ativo'),
(14, 'Tapioca - CRENDEUSPAI - Queijo, carne de sol e catupiry', 14.00, 1000, 'Silvania', 'ativo'),
(15, 'Tapioca - FLOR DE MANDACARU - Queijo, bacon, frango e cream cheese', 15.00, 1000, 'Silvania', 'ativo'),
(16, 'Tapioca ASA BRANCA - Queijo, milho, frango e bacon', 15.00, 1000, 'Silvania', 'ativo'),
(17, 'Tapioca - LASQUEIRA - Queijo, bacon e frango', 14.00, 1000, 'Silvania', 'ativo'),
(18, 'Tapioca AÍ SIM - Queijo, carne de sol e bacon', 14.00, 1000, 'Silvania', 'ativo'),
(19, 'TAPIOCA SABOR PIZZA - Queijo, presunto, tomate, cebola e orégano', 14.00, 1000, 'Silvania', 'ativo'),
(20, 'Tapioca - MARIA BONITA - Queijo, carne de sol e banana da terra caramelizada na manteiga', 14.00, 1000, 'Silvania', 'ativo'),
(21, 'Tapioca - MEU XODÓ - Queijo, purê de macaxeira e carne de sol', 14.00, 1000, 'Silvania', 'ativo'),
(22, 'Tapioca - CABRA MACHO - Queijo, purê de macaxeira e frango', 14.00, 1000, 'Silvania', 'ativo'),
(23, 'Tapioca - SERTÃO - Queijo, purê de macaxeira, carne de sol e banana da terra', 15.00, 1000, 'Silvania', 'ativo'),
(24, 'TUDÃO - Até 7 sabores', 18.00, 1000, 'Suely', 'ativo'),
(25, 'TAPIOCA À MODA DO CLIENTE', 15.00, 1000, 'Silvania', 'ativo'),
(26, 'Tapioca - MARMENINO - Manteiga e coco', 8.00, 1000, 'Silvania', 'ativo'),
(27, 'VIRGULINO - Queijo e coco', 12.00, 1000, 'Silvania', 'ativo'),
(28, 'Tapioca - OXENTE - Queijo e ovo', 12.00, 1000, 'Silvania', 'ativo'),
(29, 'Tapioca - MISTA - Queijo e presunto', 12.00, 1000, 'Silvania', 'ativo'),
(30, 'VITÓRIA - Queijo e frango', 12.00, 1000, 'Suely', 'ativo'),
(31, 'Tapioca - NORDESTINA - Queijo e carne de sol', 13.00, 1000, 'Silvania', 'ativo'),
(32, 'Tapioca - PELEJA - Queijo e calabresa', 12.00, 1000, 'Silvania', 'ativo'),
(33, 'Tapioca - SUSTANÇA - Queijo e bacon', 12.00, 1000, 'Silvania', 'ativo'),
(34, 'Tapioca ARRETADA - Carne de sol e frango', 13.00, 1000, 'Silvania', 'ativo'),
(35, 'Tapioca - RAÇUDO - Carne de sol e catupiry - 2', 12.00, 1000, 'Silvania', 'ativo'),
(36, 'Tapioca - OXE - Frango e catupiry', 12.00, 1000, 'Silvania', 'ativo'),
(37, 'Tapioca - MATUTO - Frango e ovo', 12.00, 1000, 'Silvania', 'ativo'),
(38, 'VALEI-ME - Bacon e carne', 12.00, 1000, 'Suely', 'ativo'),
(39, 'ZEMARUÁ - Frango e cream cheese', 12.00, 1000, 'Silvania', 'ativo'),
(40, 'Crepioca - PEITO DE PERU, QUEIJO COALHO E TOMATE', 15.00, 1000, 'Silvania', 'ativo'),
(41, 'Crepioca - BANANA DA TERRA CARAMELIZADA, MEL E CANELA', 15.00, 1000, 'Silvania', 'ativo'),
(42, 'Crepioca - BANANA DA TERRA CARAMELIZADA E PASTA DE AMENDOIM', 15.00, 1000, 'Silvania', 'ativo'),
(43, 'Crepioca - FRANGO, ABACATE E AZEITE', 15.00, 1000, 'Silvania', 'ativo'),
(44, 'Crepioca - FRANGO, ABACATE E QUEIJO COALHO', 15.00, 1000, 'Silvania', 'ativo'),
(45, 'Crepioca - PEITO DE PERU, FRANGO', 15.00, 1000, 'Silvania', 'ativo'),
(46, 'Crepioca - PEITO DE PERU, FRANGO E QUEIJO COALHO', 15.00, 1000, 'Silvania', 'ativo'),
(47, 'Crepioca - QUEIJO COALHO, COCO E MEL', 15.00, 1000, 'Silvania', 'ativo'),
(48, 'Crepioca - QUEIJO COALHO, MORANGO E MEL', 15.00, 1000, 'Silvania', 'ativo'),
(49, 'CREPIOCA - PEITO DE PERU, QUEIJO COALHO E MILHO', 15.00, 1000, 'Silvania', 'ativo'),
(50, 'Crepioca - FRANGO, MILHO E ORÉGANO', 15.00, 1000, 'Silvania', 'ativo'),
(51, 'Crepioca - FRANGO, MILHO, QUEIJO COALHO E ORÉGANO', 15.00, 1000, 'Silvania', 'ativo'),
(52, 'Crepioca - QUEIJO COALHO, FRANGO, E ORÉGANO', 15.00, 1000, 'Silvania', 'ativo'),
(53, 'Tapioca - MASSA', 3.00, 1000, 'Silvania', 'ativo'),
(54, 'Tapioca - MANTEIGA DE GADO', 5.50, 1000, 'Silvania', 'ativo'),
(55, 'Tapioca - COCO', 5.50, 1000, 'Silvania', 'ativo'),
(56, 'Tapioca - OVO', 6.00, 1000, 'Silvania', 'ativo'),
(57, 'Tapioca - QUEIJO COALHO OU MUSSARELA', 11.00, 1000, 'Silvania', 'ativo'),
(58, 'Tapioca - CARNE DE SOL', 11.00, 1000, 'Silvania', 'ativo'),
(59, 'Tapioca - FRANGO', 11.00, 1000, 'Silvania', 'ativo'),
(60, 'Tapioca - CALABRESA', 8.00, 1000, 'Silvania', 'ativo'),
(61, 'Tapioca Doce - DOÇURA - Café e doce de leite', 12.00, 1000, 'Silvania', 'ativo'),
(62, 'Tapioca Doce - LUIZA - Leite condensado, coco e queijo', 13.00, 1000, 'Silvania', 'ativo'),
(63, 'TERNURA - Pasta de amendoim e nutella', 14.00, 1000, 'Silvania', 'ativo'),
(64, 'Tapioca Doce - DOCINHO - Leite condensado e coco', 12.00, 1000, 'Silvania', 'ativo'),
(65, 'Tapioca Doce - FILHO DE MÃE - Brigadeiro', 12.00, 1000, 'Silvania', 'ativo'),
(66, 'Tapioca Doce - MORENINHA - Brigadeiro e morango', 14.00, 1000, 'Silvania', 'ativo'),
(67, 'Tapioca Doce - PITÉU - Nutella', 12.00, 1000, 'Silvania', 'ativo'),
(68, 'Tapioca Doce - DELICADA - Nutella e morango', 15.00, 1000, 'Silvania', 'ativo'),
(69, 'Tapioca Doce - ROMEU E JULIETA - Goiabada e queijo', 12.00, 1000, 'Silvania', 'ativo'),
(70, 'COXINHA - Frango e frango catupiry', 6.00, 1000, 'Suely', 'ativo'),
(71, 'MINI COXINHA NO COPO', 9.00, 1000, 'Suely', 'ativo'),
(72, 'BAURU - Misto e frango com queijo', 7.00, 1000, 'Suely', 'ativo'),
(73, 'CACHORRO QUENTE DE CARNE - Molho de carne, salsicha, vinagrete, batata e queijo ralado', 7.00, 1000, 'Suely', 'ativo'),
(74, 'CACHORRO QUENTE DE FRANGO - Molho de Frango, salsicha, vinagrete, batata e queijo ralado', 7.00, 1000, 'Suely', 'ativo'),
(75, 'EMPADA', 4.50, 1000, 'Suely', 'ativo'),
(76, 'ENROLADINHO', 7.00, 1000, 'Suely', 'ativo'),
(77, 'BOLO', 5.00, 1000, 'Suely', 'ativo'),
(78, 'CALDO DE MACAXEIRA', 10.00, 1000, 'Silvania', 'ativo'),
(79, 'MACAXEIRA COM CARNE DE SOL', 20.00, 1000, 'Suely', 'ativo'),
(80, 'MACAXEIRA COM OVO', 12.00, 1000, 'Suely', 'ativo'),
(81, 'CUSCUZ COM CARNE DE SOL', 20.00, 1000, 'Suely', 'ativo'),
(82, 'CUSCUZ COM OVO', 12.00, 1000, 'Suely', 'ativo'),
(83, 'MACARRÃO À BOLONHESA', 12.00, 1000, 'Suely', 'ativo'),
(84, 'CAFÉ', 2.50, 1000, 'Silvania', 'ativo'),
(85, 'CAFÉ COM LEITE', 2.50, 1000, 'Silvania', 'ativo'),
(86, 'ÁGUA MINERAL', 2.50, 1000, 'Silvania', 'ativo'),
(87, 'ÁGUA COM GÁS', 3.00, 1000, 'Silvania', 'ativo'),
(88, 'REFRIGERANTE 1L (Coca-cola, Guaraná e Fanta)', 8.00, 1000, 'Silvania', 'ativo'),
(89, 'REFRIGERANTE 250 ML', 3.50, 1000, 'Silvania', 'ativo'),
(90, 'REFRIGERANTE LATA 350ML (Coca-cola, Guaraná, Fanta)', 6.00, 1000, 'Silvania', 'ativo'),
(91, 'COCA ZERO LATA', 6.00, 1000, 'Silvania', 'ativo'),
(92, 'SUCO / COPO', 6.00, 1000, 'Suely', 'ativo'),
(93, 'SUCO / JARRA', 10.00, 1000, 'Suely', 'ativo');

-- --------------------------------------------------------

--
-- Estrutura para tabela `tentativas_login`
--

CREATE TABLE `tentativas_login` (
  `id` int(11) NOT NULL,
  `ip` varchar(45) NOT NULL,
  `data_tentativa` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(11) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `login` varchar(50) NOT NULL,
  `senha` varchar(64) NOT NULL,
  `tipo` enum('admin','funcionario') NOT NULL DEFAULT 'funcionario',
  `status` enum('ativo','inativo') DEFAULT 'ativo',
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `login`, `senha`, `tipo`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Administrador', 'admin', '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9', 'admin', 'ativo', '2024-11-30 23:05:11', '2024-11-30 23:05:11');

-- --------------------------------------------------------

--
-- Estrutura para tabela `vendas`
--

CREATE TABLE `vendas` (
  `id` int(11) NOT NULL,
  `garcom` int(11) NOT NULL,
  `mesa` varchar(10) NOT NULL,
  `forma_pagamento` varchar(50) NOT NULL,
  `data_venda` datetime NOT NULL,
  `status` varchar(20) DEFAULT 'concluida',
  `total` decimal(10,2) DEFAULT '0.00'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Despejando dados para a tabela `vendas`
--

INSERT INTO `vendas` (`id`, `garcom`, `mesa`, `forma_pagamento`, `data_venda`, `status`, `total`) VALUES
(16, 1, '10', 'dinheiro', '2024-11-28 19:52:20', 'finalizada', 0.00),
(17, 1, '5', 'pix', '2024-11-28 20:03:05', 'finalizada', 0.00),
(18, 1, '6', 'cartao_debito', '2024-11-28 20:05:22', 'finalizada', 0.00),
(19, 1, '4', 'pix', '2024-11-28 20:28:45', 'finalizada', 0.00);

-- --------------------------------------------------------

--
-- Estrutura para tabela `vendas_temp`
--

CREATE TABLE `vendas_temp` (
  `id` int(11) NOT NULL,
  `garcom_id` int(11) NOT NULL,
  `produto_id` int(11) NOT NULL,
  `quantidade` int(11) NOT NULL,
  `pagamento` enum('PIX','Dinheiro','Cartão de Crédito','Cartão de Débito') NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `financeiro`
--
ALTER TABLE `financeiro`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `garcons`
--
ALTER TABLE `garcons`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `itens_pedidos`
--
ALTER TABLE `itens_pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pedido_id` (`pedido_id`),
  ADD KEY `produto_id` (`produto_id`);

--
-- Índices de tabela `itens_venda`
--
ALTER TABLE `itens_venda`
  ADD PRIMARY KEY (`id`),
  ADD KEY `venda_id` (`venda_id`),
  ADD KEY `produto_id` (`produto_id`);

--
-- Índices de tabela `log_acessos`
--
ALTER TABLE `log_acessos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuario` (`usuario_id`);

--
-- Índices de tabela `mesas`
--
ALTER TABLE `mesas`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx_numero_mesa` (`numero`);

--
-- Índices de tabela `pagamentos_venda`
--
ALTER TABLE `pagamentos_venda`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_venda_id` (`venda_id`);

--
-- Índices de tabela `pedidos`
--
ALTER TABLE `pedidos`
  ADD PRIMARY KEY (`id`),
  ADD KEY `produto_id` (`produto_id`);

--
-- Índices de tabela `ponto`
--
ALTER TABLE `ponto`
  ADD PRIMARY KEY (`id`),
  ADD KEY `funcionario_id` (`funcionario_id`);

--
-- Índices de tabela `produtos`
--
ALTER TABLE `produtos`
  ADD PRIMARY KEY (`id`);

--
-- Índices de tabela `tentativas_login`
--
ALTER TABLE `tentativas_login`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_ip_data` (`ip`,`data_tentativa`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `login` (`login`);

--
-- Índices de tabela `vendas`
--
ALTER TABLE `vendas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `garcom` (`garcom`),
  ADD KEY `idx_data_venda` (`data_venda`);

--
-- Índices de tabela `vendas_temp`
--
ALTER TABLE `vendas_temp`
  ADD PRIMARY KEY (`id`),
  ADD KEY `garcom_id` (`garcom_id`),
  ADD KEY `produto_id` (`produto_id`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `financeiro`
--
ALTER TABLE `financeiro`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `funcionarios`
--
ALTER TABLE `funcionarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de tabela `garcons`
--
ALTER TABLE `garcons`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de tabela `itens_pedidos`
--
ALTER TABLE `itens_pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `itens_venda`
--
ALTER TABLE `itens_venda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT de tabela `log_acessos`
--
ALTER TABLE `log_acessos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `mesas`
--
ALTER TABLE `mesas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `pagamentos_venda`
--
ALTER TABLE `pagamentos_venda`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de tabela `pedidos`
--
ALTER TABLE `pedidos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24;

--
-- AUTO_INCREMENT de tabela `ponto`
--
ALTER TABLE `ponto`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `produtos`
--
ALTER TABLE `produtos`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=94;

--
-- AUTO_INCREMENT de tabela `tentativas_login`
--
ALTER TABLE `tentativas_login`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de tabela `vendas`
--
ALTER TABLE `vendas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT de tabela `vendas_temp`
--
ALTER TABLE `vendas_temp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `itens_pedidos`
--
ALTER TABLE `itens_pedidos`
  ADD CONSTRAINT `itens_pedidos_ibfk_1` FOREIGN KEY (`pedido_id`) REFERENCES `pedidos` (`id`),
  ADD CONSTRAINT `itens_pedidos_ibfk_2` FOREIGN KEY (`produto_id`) REFERENCES `produtos` (`id`);

--
-- Restrições para tabelas `log_acessos`
--
ALTER TABLE `log_acessos`
  ADD CONSTRAINT `log_acessos_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
