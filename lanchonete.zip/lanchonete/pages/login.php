<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

require_once '../includes/functions.php';
try {
    require_once '../includes/conexao.php';
} catch (Exception $e) {
    logError("Erro ao incluir arquivo de conexão: " . $e->getMessage(), "ERROR", "login.log");
    die("Erro ao conectar ao sistema. Por favor, tente novamente mais tarde.");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Log dos dados recebidos (sem a senha)
        logError("Tentativa de login - Login: " . $_POST['login'], "INFO", "login.log");
        
        // Validação dos campos
        if (!isset($_POST['login']) || !isset($_POST['senha'])) {
            throw new Exception("Campos de login ou senha não foram enviados");
        }

        $login = trim($_POST['login']);
        $senha = trim($_POST['senha']);

        if (empty($login) || empty($senha)) {
            throw new Exception("Por favor, preencha todos os campos!");
        }

        // Verifica se a tabela existe
        $checkTable = $pdo->query("SHOW TABLES LIKE 'usuarios'");
        if ($checkTable->rowCount() === 0) {
            throw new Exception("Erro na estrutura do banco de dados");
        }

        // Consulta ao banco de dados
        $stmt = $pdo->prepare("SELECT * FROM usuarios WHERE login = :login AND senha = SHA2(:senha, 256) AND status = 'ativo'");
        if (!$stmt) {
            throw new Exception("Erro ao preparar consulta");
        }

        $stmt->execute(['login' => $login, 'senha' => $senha]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario) {
            // Log de sucesso
            logError("Login bem-sucedido para usuário: " . $login, "INFO", "login.log");
            
            // Configurar sessão
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['nome'] = $usuario['nome'];
            $_SESSION['usuario_tipo'] = $usuario['tipo'];
            $_SESSION['login_time'] = time();

            // Redirecionar baseado no tipo
            $redirect = $usuario['tipo'] === 'admin' ? 'dashboard.php' : 'ponto_funcionarios.php';
            header("Location: $redirect");
            exit;
        } else {
            // Log de falha
            logError("Falha no login - credenciais inválidas para: " . $login, "ERROR", "login.log");
            throw new Exception("Login ou senha inválidos!");
        }

    } catch (PDOException $e) {
        logError("Erro PDO: " . $e->getMessage(), "ERROR", "login.log");
        $erro = "Erro ao tentar fazer login. Por favor, tente novamente.";
    } catch (Exception $e) {
        logError("Erro geral: " . $e->getMessage(), "ERROR", "login.log");
        $erro = $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Lanchonete</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
        }
        .login-container {
            background: white;
            padding: 2rem;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 400px;
        }
        .logo {
            text-align: center;
            margin-bottom: 2rem;
        }
        .form-control:focus {
            box-shadow: 0 0 0 0.25rem rgba(13,110,253,.25);
            border-color: #86b7fe;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-12 col-md-6 col-lg-4">
                <div class="login-container">
                    <div class="logo">
                        <h2 class="mb-4">Sistema de Lanchonete</h2>
                    </div>
                    <form id="loginForm" method="POST" action="">
                        <div class="mb-3">
                            <label for="login" class="form-label">Login</label>
                            <input type="text" class="form-control" id="login" name="login" required 
                                   value="<?php echo isset($_POST['login']) ? htmlspecialchars($_POST['login']) : ''; ?>">
                        </div>
                        <div class="mb-3">
                            <label for="senha" class="form-label">Senha</label>
                            <input type="password" class="form-control" id="senha" name="senha" required>
                        </div>
                        <button type="submit" class="btn btn-primary w-100">Entrar</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
    <script>
        // Mostrar erro se existir
        <?php if (isset($erro)): ?>
        Swal.fire({
            icon: 'error',
            title: 'Erro',
            text: '<?php echo $erro; ?>',
            confirmButtonColor: '#3085d6'
        });
        <?php endif; ?>

        // Validação do formulário
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            const login = document.getElementById('login').value.trim();
            const senha = document.getElementById('senha').value.trim();
            
            if (!login || !senha) {
                e.preventDefault();
                Swal.fire({
                    icon: 'warning',
                    title: 'Atenção',
                    text: 'Por favor, preencha todos os campos!',
                    confirmButtonColor: '#3085d6'
                });
            }
        });
    </script>
</body>
</html>
