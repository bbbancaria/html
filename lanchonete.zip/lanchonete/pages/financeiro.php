<?php
// Inicia a sessão
session_start();

// Verifica se o usuário está logado
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    echo "<script>alert('Acesso negado! Somente administradores podem acessar esta página.'); window.location.href = 'dashboard.php';</script>";
    exit;
}

// Conexão com o banco de dados
require '../config/database.php';

try {
    // Ajuste o nome da tabela abaixo para o correto no seu banco de dados
    $stmt = $pdo->query("SELECT * FROM pedidos ORDER BY data DESC");
    $pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro ao carregar os dados: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Financeiro</title>
    <link rel="stylesheet" href="../assets/css/global.css">
</head>
<body>
    <div class="container">
        <h1>Relatório Financeiro</h1>
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Produto</th>
                    <th>Quantidade</th>
                    <th>Total</th>
                    <th>Data</th>
                </tr>
            </thead>
            <tbody>
                <?php if (count($pedidos) > 0): ?>
                    <?php foreach ($pedidos as $pedido): ?>
                        <tr>
                            <td><?= htmlspecialchars($pedido['id']) ?></td>
                            <td><?= htmlspecialchars($pedido['produto']) ?></td>
                            <td><?= htmlspecialchars($pedido['quantidade']) ?></td>
                            <td>R$ <?= number_format($pedido['total'], 2, ',', '.') ?></td>
                            <td><?= htmlspecialchars(date('d/m/Y H:i:s', strtotime($pedido['data']))) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="5">Nenhum registro encontrado.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <a href="dashboard.php" class="btn">Voltar ao Dashboard</a>
    </div>
</body>
</html>
