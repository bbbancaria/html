<?php
include '../includes/conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $senha = $_POST['senha'];

    // Validar se os campos foram preenchidos
    if (empty($nome) || empty($senha)) {
        die('Por favor, preencha todos os campos.');
    }

    // Hash da senha para segurança
    $senhaHash = password_hash($senha, PASSWORD_BCRYPT);

    // Inserir funcionário no banco de dados
    $stmt = $pdo->prepare("INSERT INTO funcionarios (nome, senha) VALUES (:nome, :senha)");
    $stmt->execute([
        'nome' => $nome,
        'senha' => $senhaHash
    ]);

    echo "<script>alert('Funcionário cadastrado com sucesso!'); window.location.href='dashboard.php';</script>";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Funcionário</title>
    <link rel="stylesheet" href="../assets/css/global.css">
</head>
<body>
    <div class="container">
        <h1>Cadastrar Funcionário</h1>
        <form method="POST">
            <div class="form-group">
                <label for="nome">Nome do Funcionário:</label>
                <input type="text" name="nome" id="nome" required>
            </div>

            <div class="form-group">
                <label for="senha">Senha:</label>
                <input type="password" name="senha" id="senha" required>
            </div>

            <button type="submit" class="btn btn-blue">Cadastrar Funcionário</button>
        </form>
        <a href="dashboard.php" class="btn btn-red">Voltar ao Dashboard</a>
    </div>
</body>
</html>



