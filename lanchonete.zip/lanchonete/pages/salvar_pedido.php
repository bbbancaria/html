<?php
session_start();
require_once '../includes/conexao.php';

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Não autorizado']);
    exit;
}

// Recebe os dados do pedido
$mesa = filter_input(INPUT_POST, 'mesa', FILTER_SANITIZE_NUMBER_INT);
$garcom_id = filter_input(INPUT_POST, 'garcom_id', FILTER_SANITIZE_NUMBER_INT);
$produtos = json_decode($_POST['produtos'], true);

if (empty($mesa) || empty($garcom_id) || empty($produtos)) {
    echo json_encode(['error' => 'Dados incompletos']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Insere o pedido
    $stmt = $pdo->prepare("
        INSERT INTO pedidos (mesa, garcom_id, status, data_hora) 
        VALUES (:mesa, :garcom_id, 'pendente', NOW())
    ");
    
    $stmt->execute([
        'mesa' => $mesa,
        'garcom_id' => $garcom_id
    ]);
    
    $pedido_id = $pdo->lastInsertId();

    // Insere os itens do pedido
    $stmt = $pdo->prepare("
        INSERT INTO itens_pedido (pedido_id, produto_id, quantidade) 
        VALUES (:pedido_id, :produto_id, :quantidade)
    ");

    foreach ($produtos as $produto) {
        $stmt->execute([
            'pedido_id' => $pedido_id,
            'produto_id' => $produto['id'],
            'quantidade' => 1 // Você pode adicionar campo de quantidade no frontend
        ]);
    }

    // Registra o log
    $stmt = $pdo->prepare("
        INSERT INTO log_sistema (usuario_id, acao, tabela, registro_id, data_hora)
        VALUES (:usuario_id, 'criar', 'pedidos', :pedido_id, NOW())
    ");
    
    $stmt->execute([
        'usuario_id' => $_SESSION['usuario_id'],
        'pedido_id' => $pedido_id
    ]);

    $pdo->commit();
    
    echo json_encode([
        'success' => true,
        'pedido_id' => $pedido_id
    ]);

} catch (PDOException $e) {
    $pdo->rollBack();
    error_log("Erro ao salvar pedido: " . $e->getMessage());
    echo json_encode(['error' => 'Erro ao salvar pedido']);
}