<?php
session_start();
include '../includes/conexao.php';

// Obtém os detalhes do pedido
$pedido_id = $_GET['pedido_id'] ?? null;

if ($pedido_id) {
    $stmt = $pdo->prepare("
        SELECT 
            p.id AS pedido_id, 
            prod.nome AS produto, 
            p.quantidade, 
            p.mesa, 
            f.nome AS garcom, 
            DATE_FORMAT(p.data_pedido, '%d/%m/%Y %H:%i') AS data_pedido_formatada
        FROM pedidos p
        INNER JOIN produtos prod ON p.produto_id = prod.id
        INNER JOIN funcionarios f ON p.garcom_id = f.id
        WHERE p.id = :pedido_id
    ");
    $stmt->execute([':pedido_id' => $pedido_id]);
    $pedido = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$pedido) {
        echo "<script>alert('Pedido não encontrado!'); window.location.href = 'dashboard.php';</script>";
        exit();
    }
} else {
    echo "<script>alert('Pedido inválido!'); window.location.href = 'dashboard.php';</script>";
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Recibo do Pedido</title>
    <link rel="stylesheet" href="../assets/css/recibo.css">
    <script>
        window.onload = function () {
            window.print();
        }
    </script>
</head>
<body>
    <div class="recibo">
        <h1>Recibo do Pedido</h1>
        <p><strong>Número do Pedido:</strong> <?= htmlspecialchars($pedido['pedido_id']) ?></p>
        <p><strong>Produto:</strong> <?= htmlspecialchars($pedido['produto']) ?></p>
        <p><strong>Quantidade:</strong> <?= htmlspecialchars($pedido['quantidade']) ?></p>
        <p><strong>Mesa:</strong> <?= htmlspecialchars($pedido['mesa']) ?></p>
        <p><strong>Garçom:</strong> <?= htmlspecialchars($pedido['garcom']) ?></p>
        <p><strong>Data do Pedido:</strong> <?= htmlspecialchars($pedido['data_pedido_formatada']) ?></p>
        <p><strong>Status:</strong> Enviado para a cozinha</p>

        <!-- Botão de Voltar -->
        <button class="btn-voltar" onclick="window.location.href='pedidos.php';">Voltar</button>
    </div>
</body>
</html>
