<?php
// Inclua a conexão com o banco de dados
include '../includes/conexao.php';

// Verifica se o ID do pedido foi passado via GET
if (isset($_GET['id'])) {
    $pedido_id = intval($_GET['id']);

    try {
        // Atualiza o status do pedido para "Finalizado"
        $stmt = $pdo->prepare("UPDATE pedidos SET status = 'Finalizado' WHERE id = :id");
        $stmt->execute([':id' => $pedido_id]);

        // Redireciona de volta para a página da cozinha
        echo "<script>
                alert('Pedido finalizado com sucesso!');
                window.location.href = 'cozinha.php';
              </script>";
    } catch (PDOException $e) {
        // Mostra uma mensagem de erro caso algo dê errado
        echo "<script>
                alert('Erro ao finalizar pedido: " . $e->getMessage() . "');
                window.location.href = 'cozinha.php';
              </script>";
    }
} else {
    // Caso o ID do pedido não seja fornecido, redireciona para a cozinha
    echo "<script>
            alert('ID do pedido não fornecido.');
            window.location.href = 'cozinha.php';
          </script>";
}
?>
