<?php
include '../includes/conexao.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $preco = $_POST['preco'];
    $socia = $_POST['socia'];

    $stmt = $pdo->prepare("INSERT INTO produtos (nome, preco, socia) VALUES (:nome, :preco, :socia)");
    $stmt->execute(['nome' => $nome, 'preco' => $preco, 'socia' => $socia]);

    echo "<script>alert('Produto adicionado com sucesso!');</script>";
    echo "<script>window.location.href = 'vendas.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Adicionar Produto</title>
</head>
<body>
    <form method="POST">
        <label for="nome">Nome do Produto:</label>
        <input type="text" name="nome" required>
        
        <label for="preco">Preço:</label>
        <input type="number" name="preco" step="0.01" required>
        
        <label for="socia">Sócia Responsável:</label>
        <select name="socia">
            <option value="Silvania">Silvania</option>
            <option value="Suely">Suely</option>
        </select>
        
        <button type="submit">Adicionar Produto</button>
    </form>
</body>
</html>
