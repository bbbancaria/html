<?php
session_start();
require_once '../includes/conexao.php';
header('Content-Type: application/json');

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'Não autorizado']);
    exit;
}

$termo = isset($_GET['termo']) ? filter_var($_GET['termo'], FILTER_SANITIZE_STRING) : '';

try {
    $stmt = $pdo->prepare("
        SELECT id, nome, preco, categoria
        FROM produtos
        WHERE nome LIKE :termo
        OR categoria LIKE :termo
        LIMIT 10
    ");
    
    $termo = "%{$termo}%";
    $stmt->bindParam(':termo', $termo, PDO::PARAM_STR);
    $stmt->execute();
    
    $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'success' => true,
        'produtos' => $produtos
    ]);
} catch (PDOException $e) {
    error_log("Erro ao buscar produtos: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Erro interno do servidor']);
}