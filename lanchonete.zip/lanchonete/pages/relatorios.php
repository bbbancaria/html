<?php
session_start();
require_once '../includes/conexao.php';

// Funções auxiliares para relatórios
function getVendasPorPeriodo($inicio, $fim) {
    global $pdo;
    
    $sql = "
        SELECT 
            v.id,
            v.data_venda,
            v.total,
            v.mesa,
            (SELECT nome FROM usuarios WHERE id = v.garcom) as garcom,
            (
                SELECT p.dona 
                FROM itens_venda iv 
                JOIN produtos p ON p.id = iv.produto_id 
                WHERE iv.venda_id = v.id 
                LIMIT 1
            ) as socia,
            (
                SELECT forma_pagamento 
                FROM pagamentos_venda 
                WHERE venda_id = v.id 
                LIMIT 1
            ) as forma_pagamento,
            (
                SELECT COUNT(*) 
                FROM itens_venda 
                WHERE venda_id = v.id
            ) as qtd_itens
        FROM vendas v
        WHERE DATE(v.data_venda) BETWEEN :inicio AND :fim
        AND v.status = 'concluida'
        ORDER BY v.data_venda DESC
    ";
    
    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':inicio' => $inicio,
        ':fim' => $fim
    ]);
    
    return $stmt->fetchAll(PDO::FETCH_ASSOC);
}

// Determina o período com base no tipo de relatório
$tipo = $_GET['tipo'] ?? 'diario';
$data = $_GET['data'] ?? date('Y-m-d');

switch($tipo) {
    case 'mensal':
        $inicio = date('Y-m-01', strtotime($data));
        $fim = date('Y-m-t', strtotime($data));
        break;
    case 'anual':
        $inicio = date('Y-01-01', strtotime($data));
        $fim = date('Y-12-31', strtotime($data));
        break;
    default: // diário
        $inicio = $data;
        $fim = $data;
}

// Busca os dados
$vendas = getVendasPorPeriodo($inicio, $fim);

// Processa os totais por sócia
$totais_por_socia = [];
$total_geral = 0;
$total_vendas = 0;

foreach ($vendas as $venda) {
    $socia = $venda['socia'] ?? 'Não definida';
    if (!isset($totais_por_socia[$socia])) {
        $totais_por_socia[$socia] = [
            'total' => 0,
            'vendas' => 0
        ];
    }
    $totais_por_socia[$socia]['total'] += $venda['total'];
    $totais_por_socia[$socia]['vendas']++;
    $total_geral += $venda['total'];
    $total_vendas++;
}

// Calcula média geral
$media_por_venda = $total_vendas > 0 ? $total_geral / $total_vendas : 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - Sistema</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
    <style>
        .card { 
            border: none;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .total-row {
            background-color: #f8f9fa;
            font-weight: bold;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container py-4">
        <!-- Botões de Navegação -->
        <div class="mb-4">
            <a href="dashboard.php" class="btn btn-secondary">
                <i class='bx bx-arrow-back'></i> Voltar ao Dashboard
            </a>
        </div>

        <div class="card mb-4">
            <div class="card-body">
                <h2 class="card-title mb-4">
                    <i class='bx bx-line-chart'></i> Relatórios
                </h2>

                <!-- Filtros -->
                <form method="GET" class="row g-3 mb-4">
                    <div class="col-md-4">
                        <label for="tipo" class="form-label">Tipo de Relatório</label>
                        <select name="tipo" id="tipo" class="form-select">
                            <option value="diario" <?= $tipo == 'diario' ? 'selected' : '' ?>>Diário</option>
                            <option value="mensal" <?= $tipo == 'mensal' ? 'selected' : '' ?>>Mensal</option>
                            <option value="anual" <?= $tipo == 'anual' ? 'selected' : '' ?>>Anual</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="data" class="form-label">Data</label>
                        <input type="date" name="data" id="data" class="form-control" value="<?= $data ?>">
                    </div>
                    <div class="col-md-4 d-flex align-items-end">
                        <button type="submit" class="btn btn-primary">
                            <i class='bx bx-search'></i> Buscar
                        </button>
                    </div>
                </form>

                <!-- Resumo por Sócia -->
                <h3 class="h4 mb-3">Resumo por Sócia</h3>
                <div class="table-responsive mb-4">
                    <table class="table table-bordered">
                        <thead class="table-light">
                            <tr>
                                <th>Sócia</th>
                                <th>Total Vendido</th>
                                <th>Qtd. Vendas</th>
                                <th>Média por Venda</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($totais_por_socia as $socia => $dados): ?>
                            <tr>
                                <td><?= htmlspecialchars($socia) ?></td>
                                <td>R$ <?= number_format($dados['total'], 2, ',', '.') ?></td>
                                <td><?= $dados['vendas'] ?></td>
                                <td>R$ <?= number_format($dados['total'] / $dados['vendas'], 2, ',', '.') ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <tr class="total-row">
                                <td>Total Geral</td>
                                <td>R$ <?= number_format($total_geral, 2, ',', '.') ?></td>
                                <td><?= $total_vendas ?></td>
                                <td>R$ <?= number_format($media_por_venda, 2, ',', '.') ?></td>
                            </tr>
                        </tbody>
                    </table>
                </div>

                <!-- Detalhamento das Vendas -->
                <h3 class="h4 mb-3">Detalhamento das Vendas</h3>
                <div class="table-responsive">
                    <table class="table table-striped">
                        <thead>
                            <tr>
                                <th>Data/Hora</th>
                                <th>Mesa</th>
                                <th>Garçom</th>
                                <th>Sócia</th>
                                <th>Forma de Pagamento</th>
                                <th>Qtd. Itens</th>
                                <th>Valor</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($vendas as $venda): ?>
                            <tr>
                                <td><?= date('d/m/Y H:i', strtotime($venda['data_venda'])) ?></td>
                                <td><?= htmlspecialchars($venda['mesa']) ?></td>
                                <td><?= htmlspecialchars($venda['garcom'] ?? 'N/A') ?></td>
                                <td><?= htmlspecialchars($venda['socia'] ?? 'Não definida') ?></td>
                                <td><?= htmlspecialchars($venda['forma_pagamento'] ?? '-') ?></td>
                                <td><?= $venda['qtd_itens'] ?></td>
                                <td>R$ <?= number_format($venda['total'], 2, ',', '.') ?></td>
                            </tr>
                            <?php endforeach; ?>
                            <?php if (empty($vendas)): ?>
                            <tr>
                                <td colspan="7" class="text-center">Nenhuma venda encontrada no período</td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>