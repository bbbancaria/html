<?php
session_start();
require_once '../includes/conexao.php';
header('Content-Type: application/json');

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'Não autorizado']);
    exit;
}

// Busca pedidos pendentes e em preparo
try {
    $stmt = $pdo->query("
        SELECT p.*, u.nome as garcom_nome,
        GROUP_CONCAT(CONCAT(ip.quantidade, 'x ', pr.nome) SEPARATOR '\n') as itens_detalhes,
        TIMESTAMPDIFF(MINUTE, p.data_hora, NOW()) as tempo_espera
        FROM pedidos p
        LEFT JOIN usuarios u ON p.garcom_id = u.id
        LEFT JOIN itens_pedido ip ON p.id = ip.pedido_id
        LEFT JOIN produtos pr ON ip.produto_id = pr.id
        WHERE p.status IN ('pendente', 'preparando')
        GROUP BY p.id
        ORDER BY p.data_hora ASC
    ");
    $pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erro ao buscar pedidos: " . $e->getMessage());
    $pedidos = [];
}

// Função para determinar a classe de cor com base no tempo de espera
function getTempoClass($minutos) {
    if ($minutos > 30) return 'bg-danger';
    if ($minutos > 15) return 'bg-warning';
    return 'bg-success';
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cozinha - Sistema</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
    <style>
        :root {
            --sidebar-width: 250px;
        }
        .sidebar {
            width: var(--sidebar-width);
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            background: #2c3e50;
            padding: 20px;
            transition: all 0.3s ease;
        }
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
        }
        .pedido-card {
            transition: all 0.3s ease;
        }
        .pedido-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        .tempo-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 0.85rem;
            padding: 0.35em 0.65em;
        }
        .mesa-numero {
            font-size: 1.8rem;
            font-weight: bold;
            color: #2c3e50;
        }
        .itens-lista {
            white-space: pre-line;
            font-size: 0.9rem;
        }
        @media (max-width: 768px) {
            .sidebar {
                margin-left: calc(var(--sidebar-width) * -1);
            }
            .main-content {
                margin-left: 0;
            }
            .sidebar.active {
                margin-left: 0;
            }
        }
        .audio-alert {
            display: none;
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo text-white mb-4">
            <i class='bx bxs-restaurant'></i> Sistema
        </div>
        <nav class="nav flex-column">
            <a class="nav-link text-white" href="dashboard.php">
                <i class='bx bxs-dashboard'></i> Dashboard
            </a>
            <a class="nav-link text-white" href="vendas.php">
                <i class='bx bxs-cart'></i> Vendas
            </a>
            <a class="nav-link text-white" href="pedidos.php">
                <i class='bx bxs-food-menu'></i> Pedidos
            </a>
            <a class="nav-link text-white active" href="cozinha.php">
                <i class='bx bxs-hot'></i> Cozinha
            </a>
            <a class="nav-link text-white" href="estoque.php">
                <i class='bx bxs-box'></i> Estoque
            </a>
            <a class="nav-link text-danger" href="logout.php">
                <i class='bx bxs-log-out'></i> Sair
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container-fluid">
            <h1>Cozinha</h1>
            <div class="row g-4" id="listaPedidos">
                <?php foreach ($pedidos as $pedido): ?>
                <div class="col-12 col-md-6 col-xl-4 pedido-item">
                    <div class="card pedido-card">
                        <div class="card-body">
                            <span class="badge <?php echo getTempoClass($pedido['tempo_espera']); ?> tempo-badge">
                                <?php echo $pedido['tempo_espera']; ?> min
                            </span>
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="mesa-numero">Mesa <?php echo htmlspecialchars($pedido['mesa']); ?></span>
                                <span class="badge bg-primary">
                                    <?php echo ucfirst($pedido['status']); ?>
                                </span>
                            </div>
                            <p class="mb-2"><i class='bx bxs-user'></i> <?php echo htmlspecialchars($pedido['garcom_nome']); ?></p>
                            <p class="mb-2"><i class='bx bxs-time'></i> <?php echo date('H:i', strtotime($pedido['data_hora'])); ?></p>
                            <div class="itens-lista"><?php echo nl2br(htmlspecialchars($pedido['itens_detalhes'])); ?></div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</body>
</html>
