<?php
session_start();
require_once '../includes/conexao.php';

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

$mensagem = '';
$tipo_mensagem = '';

// Verifica e cria a tabela produtos se não existir
try {
    $pdo->query("DESCRIBE produtos");
} catch (PDOException $e) {
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS produtos (
            id INT AUTO_INCREMENT PRIMARY KEY,
            nome VARCHAR(255) NOT NULL,
            preco DECIMAL(10,2) NOT NULL,
            estoque INT NOT NULL DEFAULT 0,
            dona VARCHAR(255) NOT NULL,
            data_cadastro DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP
        )
    ");
}

// Busca lista de sócias
try {
    $stmt = $pdo->query("SELECT id, nome FROM usuarios WHERE nivel = 'socio' OR nivel = 'socia' ORDER BY nome");
    $socios = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Se não encontrou nenhuma sócia, adiciona as opções padrão
    if (empty($socios)) {
        $socios = [
            ['id' => 1, 'nome' => 'Silvania'],
            ['id' => 2, 'nome' => 'Suely']
        ];
    }
} catch (PDOException $e) {
    error_log("Erro ao buscar sócias: " . $e->getMessage());
    // Em caso de erro, usa as opções padrão
    $socios = [
        ['id' => 1, 'nome' => 'Silvania'],
        ['id' => 2, 'nome' => 'Suely']
    ];
}

// Processa o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validação dos campos
        $nome = trim($_POST['nome'] ?? '');
        $preco = str_replace(',', '.', $_POST['preco'] ?? '');
        $quantidade = (int)($_POST['quantidade'] ?? 0);
        $socio_id = (int)($_POST['socio_id'] ?? 0);

        if (empty($nome)) {
            throw new Exception("Nome do produto é obrigatório");
        }

        if (!is_numeric($preco) || $preco <= 0) {
            throw new Exception("Preço inválido");
        }

        if ($quantidade < 0) {
            throw new Exception("Quantidade não pode ser negativa");
        }

        if ($socio_id <= 0) {
            throw new Exception("Sócia responsável é obrigatória");
        }

        // Busca o nome da sócia pelo ID
        $socia_nome = '';
        foreach ($socios as $socio) {
            if ($socio['id'] == $socio_id) {
                $socia_nome = $socio['nome'];
                break;
            }
        }

        if (empty($socia_nome)) {
            throw new Exception("Sócia não encontrada");
        }

        // Insere o produto
        $stmt = $pdo->prepare("
            INSERT INTO produtos (nome, preco, estoque, dona) 
            VALUES (:nome, :preco, :estoque, :dona)
        ");

        $stmt->execute([
            'nome' => $nome,
            'preco' => $preco,
            'estoque' => $quantidade,
            'dona' => $socia_nome
        ]);

        $mensagem = "Produto cadastrado com sucesso!";
        $tipo_mensagem = "success";

        // Limpa os campos após sucesso
        $_POST = [];

    } catch (Exception $e) {
        $mensagem = $e->getMessage();
        $tipo_mensagem = "danger";
        error_log("Erro ao cadastrar produto: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastrar Produto - Sistema</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
    <style>
        .container {
            max-width: 800px;
        }
        .card {
            border: none;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .btn-primary {
            background-color: #2c3e50;
            border-color: #2c3e50;
        }
        .btn-primary:hover {
            background-color: #34495e;
            border-color: #34495e;
        }
        .btn-outline-secondary:hover {
            background-color: #95a5a6;
            border-color: #95a5a6;
        }
        .form-label {
            font-weight: 500;
        }
        .input-group-text {
            background-color: #f8f9fa;
            border-right: none;
        }
        .form-control:focus {
            border-color: #2c3e50;
            box-shadow: 0 0 0 0.25rem rgba(44, 62, 80, 0.25);
        }
        .invalid-feedback {
            font-size: 0.875rem;
        }
        .was-validated .form-control:invalid {
            border-color: #dc3545;
            padding-right: calc(1.5em + 0.75rem);
            background-image: url("data:image/svg+xml,%3csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 12 12' width='12' height='12' fill='none' stroke='%23dc3545'%3e%3ccircle cx='6' cy='6' r='4.5'/%3e%3cpath stroke-linejoin='round' d='M5.8 3.6h.4L6 6.5z'/%3e%3ccircle cx='6' cy='8.2' r='.6' fill='%23dc3545' stroke='none'/%3e%3c/svg%3e");
            background-repeat: no-repeat;
            background-position: right calc(0.375em + 0.1875rem) center;
            background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
        }
    </style>
</head>
<body class="bg-light">
    <div class="container py-5">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">
                            <i class='bx bx-package'></i> Cadastrar Produto
                        </h2>

                        <?php if ($mensagem): ?>
                            <div class="alert alert-<?php echo $tipo_mensagem; ?> alert-dismissible fade show" role="alert">
                                <?php echo $mensagem; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <form method="POST" class="needs-validation" novalidate>
                            <!-- Nome do Produto -->
                            <div class="mb-3">
                                <label for="nome" class="form-label">Nome do Produto</label>
                                <div class="input-group has-validation">
                                    <span class="input-group-text"><i class='bx bx-package'></i></span>
                                    <input type="text" class="form-control" id="nome" name="nome" 
                                           value="<?php echo htmlspecialchars($_POST['nome'] ?? ''); ?>" 
                                           required>
                                    <div class="invalid-feedback">
                                        Por favor, informe o nome do produto.
                                    </div>
                                </div>
                            </div>

                            <!-- Preço -->
                            <div class="mb-3">
                                <label for="preco" class="form-label">Preço</label>
                                <div class="input-group has-validation">
                                    <span class="input-group-text">R$</span>
                                    <input type="text" class="form-control" id="preco" name="preco" 
                                           value="<?php echo htmlspecialchars($_POST['preco'] ?? ''); ?>"
                                           required>
                                    <div class="invalid-feedback">
                                        Por favor, informe um preço válido.
                                    </div>
                                </div>
                            </div>

                            <!-- Quantidade -->
                            <div class="mb-3">
                                <label for="quantidade" class="form-label">Quantidade</label>
                                <div class="input-group has-validation">
                                    <span class="input-group-text"><i class='bx bx-list-ol'></i></span>
                                    <input type="number" class="form-control" id="quantidade" name="quantidade" 
                                           value="<?php echo htmlspecialchars($_POST['quantidade'] ?? ''); ?>"
                                           required min="0">
                                    <div class="invalid-feedback">
                                        Por favor, informe uma quantidade válida.
                                    </div>
                                </div>
                            </div>

                            <!-- Sócia Responsável -->
                            <div class="mb-4">
                                <label for="socio_id" class="form-label">Sócia Responsável</label>
                                <div class="input-group has-validation">
                                    <span class="input-group-text"><i class='bx bx-user'></i></span>
                                    <select class="form-select" id="socio_id" name="socio_id" required>
                                        <option value="">Selecione uma sócia</option>
                                        <?php foreach ($socios as $socio): ?>
                                            <option value="<?php echo $socio['id']; ?>" 
                                                <?php echo (isset($_POST['socio_id']) && $_POST['socio_id'] == $socio['id']) ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($socio['nome']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="invalid-feedback">
                                        Por favor, selecione uma sócia responsável.
                                    </div>
                                </div>
                            </div>

                            <!-- Botões -->
                            <div class="d-grid gap-2 d-md-flex justify-content-md-end">
                                <button type="submit" class="btn btn-primary">
                                    <i class='bx bx-save'></i> Cadastrar Produto
                                </button>
                                <a href="dashboard.php" class="btn btn-outline-secondary">
                                    <i class='bx bx-arrow-back'></i> Voltar ao Dashboard
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Validação do formulário
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        form.classList.add('was-validated')
                    }, false)
                })
        })()

        // Formata o campo de preço
        document.getElementById('preco').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = (parseInt(value || '0') / 100).toFixed(2);
            e.target.value = value;
        });
    </script>
</body>
</html>