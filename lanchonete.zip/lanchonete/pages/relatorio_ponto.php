<?php
include '../includes/conexao.php';

try {
    $stmt = $pdo->prepare("
        SELECT 
            f.nome AS funcionario,
            p.entrada,
            p.saida,
            TIMESTAMPDIFF(HOUR, p.entrada, p.saida) AS horas_trabalhadas,
            f.valor_hora,
            (TIMESTAMPDIFF(HOUR, p.entrada, p.saida) * f.valor_hora) AS total_pago
        FROM ponto p
        JOIN funcionarios f ON p.funcionario_id = f.id
    ");
    $stmt->execute();
    $pontos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Erro ao gerar relatório: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Ponto</title>
    <link rel="stylesheet" href="../assets/css/global.css">
    <link rel="stylesheet" href="../assets/css/relatorio_ponto.css">
</head>
<body>
    <div class="container">
        <h1>Relatório de Ponto</h1>
        <table>
            <thead>
                <tr>
                    <th>Funcionário</th>
                    <th>Entrada</th>
                    <th>Saída</th>
                    <th>Horas Trabalhadas</th>
                    <th>Valor por Hora</th>
                    <th>Total Pago</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pontos as $ponto): ?>
                    <tr>
                        <td><?= htmlspecialchars($ponto['funcionario']) ?></td>
                        <td><?= htmlspecialchars($ponto['entrada']) ?></td>
                        <td><?= htmlspecialchars($ponto['saida'] ?: 'N/A') ?></td>
                        <td><?= $ponto['horas_trabalhadas'] >= 0 ? $ponto['horas_trabalhadas'] : 0 ?></td>
                        <td>R$ <?= number_format($ponto['valor_hora'], 2, ',', '.') ?></td>
                        <td>R$ <?= number_format($ponto['total_pago'], 2, ',', '.') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="dashboard.php" class="btn">Voltar</a>
    </div>
</body>
</html>

