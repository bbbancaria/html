<?php
session_start();
require_once '../includes/conexao.php';

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Busca produtos do banco de dados
try {
    $stmt = $pdo->query("SELECT id, nome, preco, estoque, dona FROM produtos ORDER BY nome");
    $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erro ao buscar produtos: " . $e->getMessage());
    $produtos = [];
}

// Recupera mensagens de feedback
$mensagem = $_SESSION['mensagem'] ?? '';
$tipo_mensagem = $_SESSION['tipo_mensagem'] ?? '';

// Limpa as mensagens da sessão
unset($_SESSION['mensagem'], $_SESSION['tipo_mensagem']);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Controle de Estoque - Sistema</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
    <style>
        .table > tbody > tr:nth-of-type(odd) {
            background-color: rgba(0, 0, 0, 0.02);
        }
        .btn-action {
            padding: 0.25rem 0.5rem;
            font-size: 0.875rem;
            margin: 0 0.125rem;
        }
        .btn-edit {
            color: #fff;
            background-color: #ffc107;
            border-color: #ffc107;
        }
        .btn-delete {
            color: #fff;
            background-color: #dc3545;
            border-color: #dc3545;
        }
        .nav-buttons {
            margin-bottom: 1rem;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container py-4">
        <!-- Botões de Navegação -->
        <div class="nav-buttons">
            <a href="dashboard.php" class="btn btn-secondary">
                <i class='bx bx-arrow-back'></i> Voltar ao Dashboard
            </a>
        </div>

        <!-- Mensagens de Feedback -->
        <?php if ($mensagem): ?>
            <div class="alert alert-<?php echo $tipo_mensagem; ?> alert-dismissible fade show" role="alert">
                <?php echo $mensagem; ?>
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
            </div>
        <?php endif; ?>

        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1 class="h3">
                <i class='bx bx-package'></i> Controle de Estoque
            </h1>
            <a href="cadastrar_produto.php" class="btn btn-primary">
                <i class='bx bx-plus'></i> Novo Produto
            </a>
        </div>

        <div class="card shadow-sm">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-hover align-middle">
                        <thead>
                            <tr>
                                <th>Nome</th>
                                <th>Preço</th>
                                <th>Quantidade</th>
                                <th>Sócia Responsável</th>
                                <th class="text-end">Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (!empty($produtos)): ?>
                                <?php foreach ($produtos as $produto): ?>
                                <tr>
                                    <td><?php echo htmlspecialchars($produto['nome']); ?></td>
                                    <td>R$ <?php echo number_format($produto['preco'], 2, ',', '.'); ?></td>
                                    <td><?php echo htmlspecialchars($produto['estoque']); ?></td>
                                    <td><?php echo htmlspecialchars($produto['dona']); ?></td>
                                    <td class="text-end">
                                        <a href="editar_produto.php?id=<?php echo $produto['id']; ?>" 
                                           class="btn btn-action btn-edit" title="Editar">
                                            <i class='bx bx-edit-alt'></i>
                                        </a>
                                        <a href="excluir_produto.php?id=<?php echo $produto['id']; ?>" 
                                           class="btn btn-action btn-delete" 
                                           onclick="return confirm('Tem certeza que deseja excluir este produto?')"
                                           title="Excluir">
                                            <i class='bx bx-trash'></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center py-3">
                                        <div class="alert alert-info mb-0">
                                            <i class='bx bx-info-circle'></i> Nenhum produto cadastrado.
                                        </div>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>