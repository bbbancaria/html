<?php
session_start();
require_once '../includes/conexao.php';

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Busca produtos
try {
    $stmt = $pdo->query("SELECT id, nome, preco, estoque FROM produtos WHERE status = 'ativo' ORDER BY nome");
    $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erro ao buscar produtos: " . $e->getMessage());
    $produtos = [];
}

// Busca garçons
try {
    $stmt = $pdo->query("SELECT id, nome FROM usuarios WHERE tipo = 'garcom' AND status = 'ativo' ORDER BY nome");
    $garcons = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erro ao buscar garçons: " . $e->getMessage());
    $garcons = [];
}

// Endpoint para busca de produtos via AJAX
if (isset($_GET['action']) && $_GET['action'] === 'buscar_produtos') {
    header('Content-Type: application/json');
    $termo = isset($_GET['term']) ? $_GET['term'] : '';
    
    error_log("Buscando produtos com termo: " . $termo);
    
    try {
        $stmt = $pdo->prepare("
            SELECT id, nome, preco, estoque 
            FROM produtos 
            WHERE nome LIKE :termo 
            AND status = 'ativo' 
            ORDER BY nome 
            LIMIT 10
        ");
        
        $stmt->execute(['termo' => '%' . $termo . '%']);
        $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
        
        error_log("Produtos encontrados: " . json_encode($resultados));
        
        $dados = array_map(function($item) {
            return [
                'id' => $item['id'],
                'text' => $item['nome'] . ' (R$ ' . number_format($item['preco'], 2, ',', '.') . ')',
                'preco' => $item['preco'],
                'nome' => $item['nome']
            ];
        }, $resultados);
        
        $response = ['results' => $dados];
        error_log("Resposta final: " . json_encode($response));
        echo json_encode($response);
        exit;
    } catch (PDOException $e) {
        error_log("Erro ao buscar produtos: " . $e->getMessage());
        echo json_encode(['results' => []]);
        exit;
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nova Venda - Sistema</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2-bootstrap-5-theme@1.3.0/dist/select2-bootstrap-5-theme.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.min.css" rel="stylesheet">
    <style>
        .container { max-width: 1200px; }
        .card { 
            border: none;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .nav-buttons { margin-bottom: 1rem; }
        .select2-container { width: 100% !important; }
        .table > tbody > tr:nth-of-type(odd) { background-color: rgba(0,0,0,0.02); }
        .item-list { max-height: 400px; overflow-y: auto; }
        
        .venda-card {
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 12px;
            margin: 8px;
            min-width: 250px;
            cursor: pointer;
            transition: all 0.3s ease;
        }
        
        .venda-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        
        .venda-card.active {
            border: 2px solid #0d6efd;
            background-color: #f8f9ff;
        }
        
        .venda-card.pronto {
            border-left: 4px solid #198754;
        }
        
        .venda-card.preparo {
            border-left: 4px solid #ffc107;
        }
        
        .venda-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 8px;
        }
        
        .venda-mesa {
            font-size: 1.2em;
            font-weight: bold;
        }
        
        .venda-status {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.85em;
        }
        
        .status-pronto {
            background-color: #d1e7dd;
            color: #0f5132;
        }
        
        .status-preparo {
            background-color: #fff3cd;
            color: #856404;
        }
        
        .venda-info {
            font-size: 0.9em;
            color: #666;
        }
        
        .venda-total {
            margin-top: 8px;
            font-weight: bold;
            color: #0d6efd;
        }
        
        .venda-itens {
            margin-top: 8px;
            padding-top: 8px;
            border-top: 1px solid #eee;
            font-size: 0.85em;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container py-4">
        <!-- Seção de Vendas em Andamento -->
        <div class="row mb-4">
            <div class="col-12">
                <div class="card shadow-sm">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class='bx bx-time'></i> Vendas em Andamento
                        </h5>
                    </div>
                    <div class="card-body">
                        <div class="d-flex gap-3 flex-wrap" id="vendasEmAndamento">
                            <!-- Vendas em andamento serão carregadas aqui via JavaScript -->
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Botões de Navegação -->
        <div class="mb-4">
            <a href="dashboard.php" class="btn btn-secondary">
                <i class='bx bx-arrow-back'></i> Voltar ao Dashboard
            </a>
            <button type="button" class="btn btn-primary" data-action="nova-venda">
                <i class='bx bx-plus'></i> Nova Venda
            </button>
        </div>

        <div class="card shadow-sm" id="formVenda">
            <div class="card-body">
                <h5 class="card-title">Nova Venda</h5>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="garcom" class="form-label">Garçom</label>
                        <select class="form-select" id="garcom" required>
                            <option value="">Selecione...</option>
                            <?php foreach ($garcons as $garcom): ?>
                                <option value="<?= $garcom['id'] ?>"><?= $garcom['nome'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="mesa" class="form-label">Mesa</label>
                        <select class="form-select" id="mesa" required>
                            <option value="0">Balcão</option>
                            <option value="1">Mesa 1</option>
                            <option value="2">Mesa 2</option>
                            <option value="3">Mesa 3</option>
                            <option value="4">Mesa 4</option>
                            <option value="5">Mesa 5</option>
                            <option value="6">Mesa 6</option>
                            <option value="7">Mesa 7</option>
                            <option value="8">Mesa 8</option>
                            <option value="9">Mesa 9</option>
                            <option value="10">Mesa 10</option>
                        </select>
                    </div>
                </div>
                
                <div class="row mb-3">
                    <div class="col-md-8">
                        <label for="produto" class="form-label">Produto</label>
                        <select class="form-select" id="produto">
                            <option value="">Buscar produto...</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="quantidade" class="form-label">Quantidade</label>
                        <input type="number" class="form-control" id="quantidade" value="1" min="1">
                    </div>
                </div>

                <div class="d-grid">
                    <button type="button" class="btn btn-primary" id="btnAdicionarItem">
                        <i class='bx bx-plus'></i> Adicionar Item
                    </button>
                </div>

                <div class="table-responsive mt-4">
                    <table class="table" id="tabelaItens">
                        <thead>
                            <tr>
                                <th>Produto</th>
                                <th>Quantidade</th>
                                <th>Subtotal</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="2" class="text-end"><strong>Total:</strong></td>
                                <td><strong id="totalVenda">R$ 0,00</strong></td>
                                <td></td>
                            </tr>
                        </tfoot>
                    </table>
                </div>

                <div class="form-check mb-3">
                    <input class="form-check-input" type="checkbox" id="pedidoPronto">
                    <label class="form-check-label" for="pedidoPronto">
                        Pedido está pronto/entregue
                    </label>
                </div>

                <div class="mb-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="pedidoPronto">
                        <label class="form-check-label" for="pedidoPronto">
                            Pedido está pronto/entregue
                        </label>
                    </div>
                </div>
            </div>
        </div>

        <!-- Resumo da Venda -->
        <div class="col-md-4">
            <div class="card shadow-sm">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class='bx bx-receipt'></i> Resumo da Venda
                    </h5>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-sm">
                            <thead>
                                <tr>
                                    <th>Produto</th>
                                    <th>Qtd</th>
                                    <th>Subtotal</th>
                                    <th></th>
                                </tr>
                            </thead>
                            <tbody id="resumoItens">
                            </tbody>
                            <tfoot>
                                <tr>
                                    <td colspan="2" class="text-end fw-bold">Total:</td>
                                    <td colspan="2" class="fw-bold">
                                        <span id="totalVenda">R$ 0,00</span>
                                    </td>
                                </tr>
                            </tfoot>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal de Pagamento -->
    <div class="modal fade" id="modalPagamento" tabindex="-1" aria-labelledby="modalPagamentoLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalPagamentoLabel">Pagamento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class='bx bx-info-circle'></i> Você pode dividir o pagamento em até 4 formas diferentes.
                    </div>

                    <!-- Primeira forma de pagamento -->
                    <div id="forma_pagamento_1_container">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="forma_pagamento_1" class="form-label">Forma de Pagamento 1</label>
                                <select class="form-select" id="forma_pagamento_1" name="forma_pagamento_1">
                                    <option value="">Selecione...</option>
                                    <option value="dinheiro">Dinheiro</option>
                                    <option value="pix">PIX</option>
                                    <option value="cartao_credito">Cartão de Crédito</option>
                                    <option value="cartao_debito">Cartão de Débito</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="valor_pagamento_1" class="form-label">Valor Pagamento 1</label>
                                <input type="text" class="form-control" id="valor_pagamento_1" name="valor_pagamento_1">
                            </div>
                        </div>
                    </div>

                    <!-- Segunda forma de pagamento -->
                    <div id="forma_pagamento_2_container" style="display: none;">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="forma_pagamento_2" class="form-label">Forma de Pagamento 2</label>
                                <select class="form-select" id="forma_pagamento_2" name="forma_pagamento_2">
                                    <option value="">Selecione...</option>
                                    <option value="dinheiro">Dinheiro</option>
                                    <option value="pix">PIX</option>
                                    <option value="cartao_credito">Cartão de Crédito</option>
                                    <option value="cartao_debito">Cartão de Débito</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="valor_pagamento_2" class="form-label">Valor Pagamento 2</label>
                                <input type="text" class="form-control" id="valor_pagamento_2" name="valor_pagamento_2">
                            </div>
                        </div>
                    </div>

                    <!-- Terceira forma de pagamento -->
                    <div id="forma_pagamento_3_container" style="display: none;">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="forma_pagamento_3" class="form-label">Forma de Pagamento 3</label>
                                <select class="form-select" id="forma_pagamento_3" name="forma_pagamento_3">
                                    <option value="">Selecione...</option>
                                    <option value="dinheiro">Dinheiro</option>
                                    <option value="pix">PIX</option>
                                    <option value="cartao_credito">Cartão de Crédito</option>
                                    <option value="cartao_debito">Cartão de Débito</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="valor_pagamento_3" class="form-label">Valor Pagamento 3</label>
                                <input type="text" class="form-control" id="valor_pagamento_3" name="valor_pagamento_3">
                            </div>
                        </div>
                    </div>

                    <!-- Quarta forma de pagamento -->
                    <div id="forma_pagamento_4_container" style="display: none;">
                        <div class="row mb-3">
                            <div class="col-md-6">
                                <label for="forma_pagamento_4" class="form-label">Forma de Pagamento 4</label>
                                <select class="form-select" id="forma_pagamento_4" name="forma_pagamento_4">
                                    <option value="">Selecione...</option>
                                    <option value="dinheiro">Dinheiro</option>
                                    <option value="pix">PIX</option>
                                    <option value="cartao_credito">Cartão de Crédito</option>
                                    <option value="cartao_debito">Cartão de Débito</option>
                                </select>
                            </div>
                            <div class="col-md-6">
                                <label for="valor_pagamento_4" class="form-label">Valor Pagamento 4</label>
                                <input type="text" class="form-control" id="valor_pagamento_4" name="valor_pagamento_4">
                            </div>
                        </div>
                    </div>

                    <!-- Botões para adicionar/remover formas de pagamento -->
                    <div class="row mt-3 mb-3">
                        <div class="col-12">
                            <button type="button" id="btnAdicionarFormaPagamento" class="btn btn-outline-primary">
                                <i class="bx bx-plus"></i> Adicionar forma de pagamento
                            </button>
                            <button type="button" id="btnRemoverFormaPagamento" class="btn btn-outline-danger" style="display: none;">
                                <i class="bx bx-minus"></i> Remover última forma de pagamento
                            </button>
                        </div>
                    </div>

                    <!-- Resumo dos valores -->
                    <div class="row">
                        <div class="col-md-6">
                            <p class="mb-1">Total da Venda: <strong>R$ <span id="modalTotal">0.00</span></strong></p>
                            <p class="mb-0">Valor Restante: R$ <span id="valorRestante">0.00</span></p>
                        </div>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" id="btnConfirmarPagamento" class="btn btn-primary">Confirmar Pagamento</button>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.0.19/dist/sweetalert2.all.min.js"></script>
    <script src="../assets/js/vendas.js"></script>
</body>
</html>