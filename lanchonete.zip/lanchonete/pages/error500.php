<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Erro 500 - Erro Interno do Servidor</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            background-color: #f8f9fa;
        }
        .error-container {
            text-align: center;
            padding: 2rem;
            background: white;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            max-width: 500px;
            width: 90%;
        }
        .error-code {
            font-size: 72px;
            font-weight: bold;
            color: #dc3545;
            margin-bottom: 1rem;
        }
        .error-message {
            font-size: 24px;
            color: #343a40;
            margin-bottom: 2rem;
        }
        .error-details {
            color: #6c757d;
            margin-bottom: 2rem;
        }
    </style>
</head>
<body>
    <div class="error-container">
        <div class="error-code">500</div>
        <div class="error-message">Erro Interno do Servidor</div>
        <div class="error-details">
            Desculpe, ocorreu um erro inesperado.<br>
            Nossa equipe técnica foi notificada e está trabalhando na solução.
        </div>
        <a href="/" class="btn btn-primary">Voltar para a Página Inicial</a>
    </div>

    <script>
        // Registra o erro no console
        console.error('Erro 500 ocorrido em: ' + window.location.href);
        
        // Tenta novamente após 5 segundos
        setTimeout(function() {
            window.location.reload();
        }, 5000);
    </script>
</body>
</html>
