<?php
session_start();
require_once '../includes/conexao.php';

header('Content-Type: application/json');

try {
    // Recebe e decodifica o JSON
    $json = file_get_contents('php://input');
    $dados = json_decode($json, true);

    // Verifica se o JSON é válido
    if (json_last_error() !== JSON_ERROR_NONE) {                    
        throw new Exception('Dados JSON inválidos: ' . json_last_error_msg());
    }

    // Valida campos obrigatórios
    if (empty($dados['garcom'])) throw new Exception('Garçom não selecionado');
    if (empty($dados['mesa'])) throw new Exception('Mesa não informada');
    if (empty($dados['pagamentos'])) throw new Exception('Formas de pagamento não informadas');
    if (empty($dados['itens'])) throw new Exception('Nenhum item adicionado à venda');

    // Inicia a transação
    $pdo->beginTransaction();

    // Calcula o total da venda
    $total_venda = 0;
    foreach ($dados['itens'] as $item) {
        $total_venda += $item['preco'] * $item['quantidade'];
    }

    // Valida o total dos pagamentos
    $total_pagamentos = 0;
    foreach ($dados['pagamentos'] as $pagamento) {
        $total_pagamentos += $pagamento['valor'];
    }

    if (abs($total_pagamentos - $total_venda) > 0.01) { // Permite diferença de até 1 centavo
        throw new Exception('O total dos pagamentos não corresponde ao total da venda');
    }

    // Insere a venda
    $stmt = $pdo->prepare("
        INSERT INTO vendas (garcom, mesa, data_venda, total, status) 
        VALUES (:garcom, :mesa, NOW(), :total, 'concluida')
    ");

    $stmt->execute([
        ':garcom' => $dados['garcom'],
        ':mesa' => $dados['mesa'],
        ':total' => $total_venda
    ]);

    $venda_id = $pdo->lastInsertId();

    // Insere os pagamentos
    $stmt_pagamento = $pdo->prepare("
        INSERT INTO pagamentos_venda (venda_id, forma_pagamento, valor)
        VALUES (:venda_id, :forma_pagamento, :valor)
    ");

    foreach ($dados['pagamentos'] as $pagamento) {
        $stmt_pagamento->execute([
            ':venda_id' => $venda_id,
            ':forma_pagamento' => $pagamento['forma'],
            ':valor' => $pagamento['valor']
        ]);
    }

    // Insere os itens da venda
    $stmt_item = $pdo->prepare("
        INSERT INTO itens_venda (venda_id, produto_id, quantidade, preco_unitario)
        VALUES (:venda_id, :produto_id, :quantidade, :preco_unitario)
    ");

    foreach ($dados['itens'] as $item) {
        $stmt_item->execute([
            ':venda_id' => $venda_id,
            ':produto_id' => $item['id'],
            ':quantidade' => $item['quantidade'],
            ':preco_unitario' => $item['preco']
        ]);
    }

    // Confirma a transação
    $pdo->commit();

    // Retorna sucesso
    echo json_encode([
        'success' => true,
        'message' => 'Venda realizada com sucesso!',
        'venda_id' => $venda_id
    ]);

} catch (Exception $e) {
    // Em caso de erro, desfaz a transação
    if (isset($pdo) && $pdo->inTransaction()) {
        $pdo->rollBack();
    }

    // Retorna erro
    http_response_code(400);
    echo json_encode([
        'success' => false,
        'message' => $e->getMessage()
    ]);
}