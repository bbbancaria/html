<?php
session_start();
require_once '../includes/conexao.php';

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

$mensagem = '';
$tipo_mensagem = '';

// Verifica se foi fornecido um ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: estoque.php');
    exit;
}

$id = (int)$_GET['id'];

// Busca o produto
try {
    $stmt = $pdo->prepare("SELECT * FROM produtos WHERE id = ?");
    $stmt->execute([$id]);
    $produto = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$produto) {
        header('Location: estoque.php');
        exit;
    }
} catch (PDOException $e) {
    error_log("Erro ao buscar produto: " . $e->getMessage());
    header('Location: estoque.php');
    exit;
}

// Busca lista de sócias
try {
    $stmt = $pdo->query("SELECT id, nome FROM usuarios WHERE nivel = 'socio' OR nivel = 'socia' ORDER BY nome");
    $socios = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    if (empty($socios)) {
        $socios = [
            ['id' => 1, 'nome' => 'Silvania'],
            ['id' => 2, 'nome' => 'Suely']
        ];
    }
} catch (PDOException $e) {
    error_log("Erro ao buscar sócias: " . $e->getMessage());
    $socios = [
        ['id' => 1, 'nome' => 'Silvania'],
        ['id' => 2, 'nome' => 'Suely']
    ];
}

// Processa o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        // Validação dos campos
        $nome = trim($_POST['nome'] ?? '');
        $preco = str_replace(',', '.', $_POST['preco'] ?? '');
        $quantidade = (int)($_POST['quantidade'] ?? 0);
        $socio_id = (int)($_POST['socio_id'] ?? 0);

        if (empty($nome)) {
            throw new Exception("Nome do produto é obrigatório");
        }

        if (!is_numeric($preco) || $preco <= 0) {
            throw new Exception("Preço inválido");
        }

        if ($quantidade < 0) {
            throw new Exception("Quantidade não pode ser negativa");
        }

        if ($socio_id <= 0) {
            throw new Exception("Sócia responsável é obrigatória");
        }

        // Busca o nome da sócia pelo ID
        $socia_nome = '';
        foreach ($socios as $socio) {
            if ($socio['id'] == $socio_id) {
                $socia_nome = $socio['nome'];
                break;
            }
        }

        if (empty($socia_nome)) {
            throw new Exception("Sócia não encontrada");
        }

        // Atualiza o produto
        $stmt = $pdo->prepare("
            UPDATE produtos 
            SET nome = :nome, 
                preco = :preco, 
                estoque = :estoque, 
                dona = :dona 
            WHERE id = :id
        ");

        $stmt->execute([
            'nome' => $nome,
            'preco' => $preco,
            'estoque' => $quantidade,
            'dona' => $socia_nome,
            'id' => $id
        ]);

        header('Location: estoque.php');
        exit;

    } catch (Exception $e) {
        $mensagem = $e->getMessage();
        $tipo_mensagem = "danger";
        error_log("Erro ao atualizar produto: " . $e->getMessage());
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Produto - Sistema</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
    <style>
        .container {
            max-width: 800px;
        }
        .card {
            border: none;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        .nav-buttons {
            margin-bottom: 1rem;
        }
    </style>
</head>
<body class="bg-light">
    <div class="container py-5">
        <!-- Botões de Navegação -->
        <div class="nav-buttons">
            <a href="estoque.php" class="btn btn-secondary">
                <i class='bx bx-arrow-back'></i> Voltar ao Estoque
            </a>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card shadow">
                    <div class="card-body">
                        <h2 class="card-title text-center mb-4">
                            <i class='bx bx-edit'></i> Editar Produto
                        </h2>

                        <?php if ($mensagem): ?>
                            <div class="alert alert-<?php echo $tipo_mensagem; ?> alert-dismissible fade show" role="alert">
                                <?php echo $mensagem; ?>
                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>
                        <?php endif; ?>

                        <form method="POST" class="needs-validation" novalidate>
                            <!-- Nome do Produto -->
                            <div class="mb-3">
                                <label for="nome" class="form-label">Nome do Produto</label>
                                <div class="input-group has-validation">
                                    <span class="input-group-text"><i class='bx bx-package'></i></span>
                                    <input type="text" class="form-control" id="nome" name="nome" 
                                           value="<?php echo htmlspecialchars($produto['nome']); ?>" 
                                           required>
                                    <div class="invalid-feedback">
                                        Por favor, informe o nome do produto.
                                    </div>
                                </div>
                            </div>

                            <!-- Preço -->
                            <div class="mb-3">
                                <label for="preco" class="form-label">Preço</label>
                                <div class="input-group has-validation">
                                    <span class="input-group-text">R$</span>
                                    <input type="text" class="form-control" id="preco" name="preco" 
                                           value="<?php echo number_format($produto['preco'], 2, ',', ''); ?>"
                                           required>
                                    <div class="invalid-feedback">
                                        Por favor, informe um preço válido.
                                    </div>
                                </div>
                            </div>

                            <!-- Quantidade -->
                            <div class="mb-3">
                                <label for="quantidade" class="form-label">Quantidade</label>
                                <div class="input-group has-validation">
                                    <span class="input-group-text"><i class='bx bx-list-ol'></i></span>
                                    <input type="number" class="form-control" id="quantidade" name="quantidade" 
                                           value="<?php echo htmlspecialchars($produto['estoque']); ?>"
                                           required min="0">
                                    <div class="invalid-feedback">
                                        Por favor, informe uma quantidade válida.
                                    </div>
                                </div>
                            </div>

                            <!-- Sócia Responsável -->
                            <div class="mb-4">
                                <label for="socio_id" class="form-label">Sócia Responsável</label>
                                <div class="input-group has-validation">
                                    <span class="input-group-text"><i class='bx bx-user'></i></span>
                                    <select class="form-select" id="socio_id" name="socio_id" required>
                                        <option value="">Selecione uma sócia</option>
                                        <?php foreach ($socios as $socio): ?>
                                            <option value="<?php echo $socio['id']; ?>" 
                                                <?php echo $produto['dona'] == $socio['nome'] ? 'selected' : ''; ?>>
                                                <?php echo htmlspecialchars($socio['nome']); ?>
                                            </option>
                                        <?php endforeach; ?>
                                    </select>
                                    <div class="invalid-feedback">
                                        Por favor, selecione uma sócia responsável.
                                    </div>
                                </div>
                            </div>

                            <!-- Botões -->
                            <div class="d-grid gap-2">
                                <button type="submit" class="btn btn-primary">
                                    <i class='bx bx-save'></i> Salvar Alterações
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        // Validação do formulário
        (function () {
            'use strict'
            var forms = document.querySelectorAll('.needs-validation')
            Array.prototype.slice.call(forms)
                .forEach(function (form) {
                    form.addEventListener('submit', function (event) {
                        if (!form.checkValidity()) {
                            event.preventDefault()
                            event.stopPropagation()
                        }
                        form.classList.add('was-validated')
                    }, false)
                })
        })()

        // Formata o campo de preço
        document.getElementById('preco').addEventListener('input', function(e) {
            let value = e.target.value.replace(/\D/g, '');
            value = (parseInt(value || '0') / 100).toFixed(2);
            e.target.value = value.replace('.', ',');
        });
    </script>
</body>
</html>