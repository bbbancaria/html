<?php
session_start();
include '../includes/conexao.php';

// Verificar se o funcionário está logado
if (!isset($_SESSION['funcionario_id'])) {
    header('Location: login.php');
    exit;
}

$funcionario_id = $_SESSION['funcionario_id'];
$funcionario_nome = $_SESSION['funcionario_nome'];

// Registrar entrada
if (isset($_POST['registrar_entrada'])) {
    $stmt = $pdo->prepare("INSERT INTO ponto (funcionario_id, tipo, horario) VALUES (:funcionario_id, 'entrada', NOW())");
    $stmt->execute(['funcionario_id' => $funcionario_id]);
    echo "<script>alert('Entrada registrada com sucesso!');</script>";
}

// Registrar saída
if (isset($_POST['registrar_saida'])) {
    $stmt = $pdo->prepare("INSERT INTO ponto (funcionario_id, tipo, horario) VALUES (:funcionario_id, 'saida', NOW())");
    $stmt->execute(['funcionario_id' => $funcionario_id]);
    echo "<script>alert('Saída registrada com sucesso!');</script>";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ponto dos Funcionários</title>
    <link rel="stylesheet" href="../assets/css/global.css">
</head>
<body>
    <div class="container">
        <h1>Ponto - <?= htmlspecialchars($funcionario_nome) ?></h1>
        <form method="POST">
            <button type="submit" name="registrar_entrada" class="btn btn-blue">Registrar Entrada</button>
            <button type="submit" name="registrar_saida" class="btn btn-blue">Registrar Saída</button>
        </form>
        <a href="dashboard.php" class="btn btn-red">Voltar ao Dashboard</a>
    </div>
</body>
</html>

