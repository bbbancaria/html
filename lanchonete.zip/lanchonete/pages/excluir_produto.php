<?php
session_start();
require_once '../includes/conexao.php';

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verifica se foi fornecido um ID
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: estoque.php');
    exit;
}

$id = (int)$_GET['id'];

try {
    // Exclui o produto
    $stmt = $pdo->prepare("DELETE FROM produtos WHERE id = ?");
    $stmt->execute([$id]);
    
    // Redireciona de volta para o estoque
    header('Location: estoque.php');
    exit;
} catch (PDOException $e) {
    error_log("Erro ao excluir produto: " . $e->getMessage());
    header('Location: estoque.php');
    exit;
}
?>