<?php
session_start();
require_once '../includes/conexao.php';

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Busca pedidos ativos
try {
    $stmt = $pdo->query("
        SELECT p.*, u.nome as garcom_nome,
        GROUP_CONCAT(CONCAT(ip.quantidade, 'x ', pr.nome) SEPARATOR ', ') as itens_detalhes
        FROM pedidos p
        LEFT JOIN usuarios u ON p.garcom_id = u.id
        LEFT JOIN itens_pedido ip ON p.id = ip.pedido_id
        LEFT JOIN produtos pr ON ip.produto_id = pr.id
        WHERE p.status != 'finalizado'
        GROUP BY p.id
        ORDER BY p.data_hora DESC
    ");
    $pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Busca garçons ativos
    $stmt = $pdo->query("SELECT id, nome FROM usuarios WHERE tipo = 'garcom' AND ativo = 1");
    $garcons = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erro ao buscar pedidos: " . $e->getMessage());
}

// Define cores para cada status
$status_cores = [
    'pendente' => 'warning',
    'preparando' => 'info',
    'pronto' => 'success',
    'entregue' => 'primary',
    'cancelado' => 'danger'
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pedidos - Sistema</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet">
    <style>
        :root {
            --sidebar-width: 250px;
        }
        .sidebar {
            width: var(--sidebar-width);
            position: fixed;
            left: 0;
            top: 0;
            height: 100%;
            background: #2c3e50;
            padding: 20px;
            transition: all 0.3s ease;
        }
        .main-content {
            margin-left: var(--sidebar-width);
            padding: 20px;
        }
        .pedido-card {
            transition: all 0.3s ease;
        }
        .pedido-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        .status-badge {
            font-size: 0.85rem;
            padding: 0.35em 0.65em;
        }
        .mesa-numero {
            font-size: 1.5rem;
            font-weight: bold;
            color: #2c3e50;
        }
        @media (max-width: 768px) {
            .sidebar {
                margin-left: calc(var(--sidebar-width) * -1);
            }
            .main-content {
                margin-left: 0;
            }
            .sidebar.active {
                margin-left: 0;
            }
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <div class="logo text-white mb-4">
            Sistema
        </div>
        <nav class="nav flex-column">
            <a class="nav-link text-white" href="dashboard.php">
                <i class='bx bxs-dashboard'></i> Dashboard
            </a>
            <a class="nav-link text-white" href="vendas.php">
                <i class='bx bxs-cart'></i> Vendas
            </a>
            <a class="nav-link text-white active" href="pedidos.php">
                <i class='bx bxs-food-menu'></i> Pedidos
            </a>
            <a class="nav-link text-white" href="cozinha.php">
                <i class='bx bxs-hot'></i> Cozinha
            </a>
            <a class="nav-link text-white" href="estoque.php">
                <i class='bx bxs-box'></i> Estoque
            </a>
            <a class="nav-link text-danger" href="logout.php">
                <i class='bx bxs-log-out'></i> Sair
            </a>
        </nav>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="container-fluid">
            <!-- Header -->
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1>Pedidos</h1>
                <button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#novoPedidoModal">
                    <i class='bx bx-plus'></i> Novo Pedido
                </button>
            </div>

            <!-- Filtros -->
            <div class="card mb-4">
                <div class="card-body">
                    <div class="row g-3">
                        <div class="col-md-3">
                            <input type="text" class="form-control" id="filtroMesa" placeholder="Filtrar por mesa...">
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" id="filtroGarcom">
                                <option value="">Todos os garçons</option>
                                <?php foreach ($garcons as $garcom): ?>
                                    <option value="<?php echo $garcom['id']; ?>">
                                        <?php echo htmlspecialchars($garcom['nome']); ?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <select class="form-select" id="filtroStatus">
                                <option value="">Todos os status</option>
                                <option value="pendente">Pendente</option>
                                <option value="preparando">Preparando</option>
                                <option value="pronto">Pronto</option>
                                <option value="entregue">Entregue</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <button class="btn btn-secondary w-100" id="limparFiltros">
                                Limpar Filtros
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Lista de Pedidos -->
            <div class="row g-4" id="listaPedidos">
                <?php foreach ($pedidos as $pedido): ?>
                <div class="col-12 col-md-6 col-xl-4 pedido-item">
                    <div class="card pedido-card">
                        <div class="card-body">
                            <div class="d-flex justify-content-between align-items-center mb-3">
                                <span class="mesa-numero">Mesa <?php echo htmlspecialchars($pedido['mesa']); ?></span>
                                <span class="badge bg-<?php echo $status_cores[$pedido['status']]; ?> status-badge">
                                    <?php echo ucfirst($pedido['status']); ?>
                                </span>
                            </div>
                            
                            <p class="mb-2">
                                <i class='bx bxs-user text-muted'></i>
                                <?php echo htmlspecialchars($pedido['garcom_nome']); ?>
                            </p>
                            
                            <p class="mb-2">
                                <i class='bx bxs-time text-muted'></i>
                                <?php echo date('H:i', strtotime($pedido['data_hora'])); ?>
                            </p>
                            
                            <div class="mb-3">
                                <small class="text-muted">Itens:</small><br>
                                <?php echo nl2br(htmlspecialchars($pedido['itens_detalhes'])); ?>
                            </div>
                            
                            <div class="d-flex justify-content-between">
                                <button class="btn btn-sm btn-outline-primary" 
                                        onclick="atualizarStatus(<?php echo $pedido['id']; ?>)">
                                    Atualizar Status
                                </button>
                                <button class="btn btn-sm btn-outline-danger"
                                        onclick="cancelarPedido(<?php echo $pedido['id']; ?>)">
                                    Cancelar
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>

    <!-- Modal Novo Pedido -->
    <div class="modal fade" id="novoPedidoModal" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Novo Pedido</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <form id="formNovoPedido">
                        <div class="row g-3">
                            <div class="col-md-6">
                                <label class="form-label">Mesa</label>
                                <input type="number" class="form-control" name="mesa" required>
                            </div>
                            <div class="col-md-6">
                                <label class="form-label">Garçom</label>
                                <select class="form-select" name="garcom_id" required>
                                    <option value="">Selecione...</option>
                                    <?php foreach ($garcons as $garcom): ?>
                                        <option value="<?php echo $garcom['id']; ?>">
                                            <?php echo htmlspecialchars($garcom['nome']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                            <div class="col-12">
                                <label class="form-label">Produtos</label>
                                <select class="form-control" id="produtos" multiple>
                                    <!-- Produtos serão carregados via AJAX -->
                                </select>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <button type="button" class="btn btn-primary" id="salvarPedido">Salvar Pedido</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Scripts -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
    <script>
        // Inicialização do Select2 para produtos
        $('#produtos').select2({
            ajax: {
                url: 'buscar_produtos.php',
                dataType: 'json',
                delay: 250,
                data: function (params) {
                    return {
                        q: params.term
                    };
                },
                processResults: function (data) {
                    return {
                        results: data.results
                    };
                },
                cache: true
            },
            minimumInputLength: 2,
            placeholder: 'Busque produtos...',
            multiple: true
        });

        // Filtros
        function aplicarFiltros() {
            const mesa = $('#filtroMesa').val().toLowerCase();
            const garcom = $('#filtroGarcom').val();
            const status = $('#filtroStatus').val();

            $('.pedido-item').each(function() {
                const $pedido = $(this);
                const mesaPedido = $pedido.find('.mesa-numero').text().toLowerCase();
                const garcomPedido = $pedido.find('.garcom').data('id');
                const statusPedido = $pedido.find('.status-badge').text().toLowerCase();

                const mesaMatch = !mesa || mesaPedido.includes(mesa);
                const garcomMatch = !garcom || garcomPedido == garcom;
                const statusMatch = !status || statusPedido === status;

                $pedido.toggle(mesaMatch && garcomMatch && statusMatch);
            });
        }

        // Event listeners para filtros
        $('#filtroMesa, #filtroGarcom, #filtroStatus').on('input change', aplicarFiltros);
        $('#limparFiltros').click(function() {
            $('#filtroMesa').val('');
            $('#filtroGarcom').val('');
            $('#filtroStatus').val('');
            aplicarFiltros();
        });

        // Atualizar status do pedido
        function atualizarStatus(pedidoId) {
            // Implementar lógica de atualização de status
        }

        // Cancelar pedido
        function cancelarPedido(pedidoId) {
            if (confirm('Tem certeza que deseja cancelar este pedido?')) {
                // Implementar lógica de cancelamento
            }
        }

        // Salvar novo pedido
        $('#salvarPedido').click(function() {
            const formData = new FormData($('#formNovoPedido')[0]);
            formData.append('produtos', JSON.stringify($('#produtos').select2('data')));

            $.ajax({
                url: 'salvar_pedido.php',
                method: 'POST',
                data: formData,
                processData: false,
                contentType: false,
                success: function(response) {
                    if (response.success) {
                        location.reload();
                    } else {
                        alert('Erro ao salvar pedido: ' + response.error);
                    }
                },
                error: function() {
                    alert('Erro ao processar requisição');
                }
            });
        });

        // Atualização automática a cada 30 segundos
        setInterval(function() {
            // Implementar atualização automática dos pedidos
        }, 30000);
    </script>
</body>
</html>
<?php
session_start();
require_once '../includes/conexao.php';

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Não autorizado']);
    exit;
}

// Recebe o termo de busca
$busca = filter_input(INPUT_GET, 'q', FILTER_SANITIZE_STRING);

if (empty($busca)) {
    header('Content-Type: application/json');
    echo json_encode(['results' => []]);
    exit;
}

try {
    // Busca produtos que correspondem ao termo de busca
    $stmt = $pdo->prepare("
        SELECT id, nome, preco, quantidade 
        FROM produtos 
        WHERE (nome LIKE :busca OR codigo LIKE :busca)
        AND ativo = 1 
        AND quantidade > 0
        LIMIT 10
    ");
    
    $stmt->execute(['busca' => "%$busca%"]);
    $produtos = $stmt->fetchAll(PDO::FETCH_ASSOC);
    
    // Formata os resultados para o Select2
    $results = array_map(function($produto) {
        return [
            'id' => $produto['id'],
            'text' => $produto['nome'],
            'preco' => (float)$produto['preco'],
            'estoque' => (int)$produto['quantidade']
        ];
    }, $produtos);
    
    header('Content-Type: application/json');
    echo json_encode(['results' => $results]);
    
} catch (PDOException $e) {
    error_log("Erro na busca de produtos: " . $e->getMessage());
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Erro ao buscar produtos']);
}