<?php
session_start();
require_once '../includes/conexao.php';
header('Content-Type: application/json');

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    echo json_encode(['success' => false, 'error' => 'Não autorizado']);
    exit;
}

// Verifica se os parâmetros necessários foram enviados
if (!isset($_POST['pedido_id']) || !isset($_POST['status'])) {
    echo json_encode(['success' => false, 'error' => 'Parâmetros inválidos']);
    exit;
}

$pedido_id = filter_var($_POST['pedido_id'], FILTER_VALIDATE_INT);
$status = filter_var($_POST['status'], FILTER_SANITIZE_STRING);

// Valida status permitidos
$status_permitidos = ['pendente', 'preparando', 'pronto'];
if (!in_array($status, $status_permitidos)) {
    echo json_encode(['success' => false, 'error' => 'Status inválido']);
    exit;
}

try {
    $stmt = $pdo->prepare("UPDATE pedidos SET status = ?, atualizado_em = NOW() WHERE id = ?");
    $resultado = $stmt->execute([$status, $pedido_id]);

    if ($resultado) {
        echo json_encode(['success' => true]);
    } else {
        echo json_encode(['success' => false, 'error' => 'Erro ao atualizar pedido']);
    }
} catch (PDOException $e) {
    error_log("Erro ao atualizar status do pedido: " . $e->getMessage());
    echo json_encode(['success' => false, 'error' => 'Erro interno do servidor']);
}
