<?php
session_start();

// Verifica se o usuário tem permissão de administrador
if (!isset($_SESSION['user_role']) || $_SESSION['user_role'] != 'admin') {
    echo "<script>alert('Acesso negado! Somente administradores podem acessar esta página.'); window.location.href = 'dashboard.php';</script>";
    exit;
}

// Conexão com o banco de dados
require '../config/database.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Valida e pega o valor enviado pelo formulário
    $novo_valor_hora = filter_input(INPUT_POST, 'valor_hora', FILTER_VALIDATE_FLOAT);

    if ($novo_valor_hora !== false && $novo_valor_hora > 0) {
        try {
            // Atualiza o valor da hora trabalhada no banco de dados
            $stmt = $pdo->prepare("UPDATE funcionarios SET valor_hora = :valor_hora");
            $stmt->bindParam(':valor_hora', $novo_valor_hora);
            $stmt->execute();

            echo "<script>alert('Valor da hora atualizado com sucesso!'); window.location.href = 'dashboard.php';</script>";
            exit;
        } catch (PDOException $e) {
            die("Erro ao atualizar o valor da hora: " . $e->getMessage());
        }
    } else {
        echo "<script>alert('Por favor, insira um valor válido para a hora trabalhada.');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurar Valor da Hora</title>
    <link rel="stylesheet" href="../assets/css/global.css">
</head>
<body>
    <div class="container">
        <h1>Configurar Valor da Hora</h1>
        <form method="POST">
            <div class="form-group">
                <label for="valor_hora">Novo Valor da Hora:</label>
                <input type="number" name="valor_hora" id="valor_hora" step="0.01" placeholder="Ex: 20.50" required>
            </div>
            <button type="submit" class="btn">Salvar</button>
        </form>
        <a href="dashboard.php" class="btn btn-red">Voltar ao Dashboard</a>
    </div>
</body>
</html>
