<?php
include '../includes/conexao.php';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $produto_id = $_POST['produto_id'];

    $stmt = $pdo->prepare("DELETE FROM produtos WHERE id = :id");
    $stmt->execute(['id' => $produto_id]);

    echo "<script>alert('Produto removido com sucesso!');</script>";
    echo "<script>window.location.href = 'vendas.php';</script>";
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Deletar Produto</title>
</head>
<body>
    <form method="POST">
        <label for="produto_id">Selecione o Produto:</label>
        <select name="produto_id" required>
            <?php
            $produtos = $pdo->query("SELECT id, nome FROM produtos")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($produtos as $produto) {
                echo "<option value='{$produto['id']}'>{$produto['nome']}</option>";
            }
            ?>
        </select>
        <button type="submit">Deletar Produto</button>
    </form>
</body>
</html>
