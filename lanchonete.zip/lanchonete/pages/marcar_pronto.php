<?php
include '../includes/conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pedido_id = $_POST['pedido_id'];

    // Atualizar status do pedido para 'pronto'
    $stmt = $pdo->prepare("UPDATE pedidos SET status = 'pronto' WHERE id = :pedido_id");
    $stmt->execute(['pedido_id' => $pedido_id]);

    // Redirecionar de volta para a cozinha
    header('Location: cozinha.php');
    exit();
}
?>
