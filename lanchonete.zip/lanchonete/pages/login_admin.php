<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';

    // Credenciais de administrador
    $admin_username = 'Max';
    $admin_password = '123456';

    if ($username === $admin_username && $password === $admin_password) {
        $_SESSION['admin_logged_in'] = true;
        header('Location: config_valor_hora.php');
        exit;
    } else {
        $error = 'Usuário ou senha inválidos!';
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Configurar Valor da Hora</title>
    <link rel="stylesheet" href="../assets/css/global.css">
</head>
<body>
    <div class="container">
        <h1>Login - Administrador</h1>
        <?php if (!empty($error)): ?>
            <p style="color: red;"><?= htmlspecialchars($error) ?></p>
        <?php endif; ?>
        <form method="POST">
            <div class="form-group">
                <label for="username">Usuário:</label>
                <input type="text" name="username" id="username" required>
            </div>
            <div class="form-group">
                <label for="password">Senha:</label>
                <input type="password" name="password" id="password" required>
            </div>
            <button type="submit" class="btn">Entrar</button>
        </form>
        <a href="dashboard.php" class="btn btn-danger">Voltar ao Dashboard</a>
    </div>
</body>
</html>
