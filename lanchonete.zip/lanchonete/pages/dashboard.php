<?php
session_start();
require_once '../includes/conexao.php';

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Inicializa as variáveis com valores padrão
$vendas_hoje = ['total' => 0, 'valor' => 0.00];
$estoque_baixo = ['total' => 0];
$pedidos_pendentes = ['total' => 0];

try {
    // Total de vendas do dia
    $stmt = $pdo->query("SELECT COUNT(*) as total, COALESCE(SUM(valor_total), 0) as valor FROM pedidos WHERE DATE(data_pedido) = CURRENT_DATE");
    if ($stmt) $vendas_hoje = $stmt->fetch(PDO::FETCH_ASSOC) ?: $vendas_hoje;

    // Produtos com estoque baixo
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM produtos WHERE quantidade <= 10");
    if ($stmt) $estoque_baixo = $stmt->fetch(PDO::FETCH_ASSOC) ?: $estoque_baixo;

    // Pedidos pendentes
    $stmt = $pdo->query("SELECT COUNT(*) as total FROM pedidos WHERE status = 'pendente'");
    if ($stmt) $pedidos_pendentes = $stmt->fetch(PDO::FETCH_ASSOC) ?: $pedidos_pendentes;

} catch (PDOException $e) {
    error_log("Erro ao buscar estatísticas: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
    <style>
        :root {
            --primary-color: #2c3e50;
            --secondary-color: #34495e;
            --accent-color: #3498db;
            --danger-color: #e74c3c;
            --success-color: #2ecc71;
            --warning-color: #f1c40f;
        }
        body {
            background-color: #f8f9fa;
        }
        .dashboard-card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            transition: transform 0.3s ease;
        }
        .dashboard-card:hover {
            transform: translateY(-5px);
        }
        .menu-card {
            height: 120px;
            display: flex;
            align-items: center;
            justify-content: center;
            text-decoration: none;
            color: white;
            background: var(--primary-color);
            border-radius: 10px;
            transition: all 0.3s ease;
        }
        .menu-card:hover {
            background: var(--secondary-color);
            color: white;
            transform: translateY(-5px);
        }
        .menu-card i {
            font-size: 2rem;
            margin-bottom: 10px;
        }
        .stats-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
        }
        .stats-card i {
            font-size: 2.5rem;
            margin-right: 15px;
        }
        .footer {
            margin-top: 50px;
            padding: 20px 0;
            color: #6c757d;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container py-5">
        <!-- Cabeçalho -->
        <div class="row mb-4">
            <div class="col-12">
                <h1 class="text-center mb-4">
                    <i class='bx bxs-dashboard text-primary'></i> Dashboard
                </h1>
                <p class="text-center text-muted">
                    Bem-vindo ao sistema de gerenciamento. Escolha uma das opções abaixo:
                </p>
            </div>
        </div>

        <!-- Cards de Estatísticas -->
        <div class="row mb-5">
            <div class="col-md-4">
                <div class="stats-card dashboard-card">
                    <div class="d-flex align-items-center">
                        <i class='bx bx-shopping-bag text-primary'></i>
                        <div>
                            <h3 class="mb-0"><?php echo $vendas_hoje['total']; ?></h3>
                            <p class="text-muted mb-0">Vendas Hoje</p>
                            <small class="text-success">
                                R$ <?php echo number_format($vendas_hoje['valor'], 2, ',', '.'); ?>
                            </small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stats-card dashboard-card">
                    <div class="d-flex align-items-center">
                        <i class='bx bx-package text-warning'></i>
                        <div>
                            <h3 class="mb-0"><?php echo $estoque_baixo['total']; ?></h3>
                            <p class="text-muted mb-0">Produtos com Estoque Baixo</p>
                            <small class="text-warning">Necessita atenção</small>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stats-card dashboard-card">
                    <div class="d-flex align-items-center">
                        <i class='bx bx-time-five text-danger'></i>
                        <div>
                            <h3 class="mb-0"><?php echo $pedidos_pendentes['total']; ?></h3>
                            <p class="text-muted mb-0">Pedidos Pendentes</p>
                            <small class="text-danger">Aguardando preparo</small>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Menu Principal -->
        <div class="row g-4">
            <!-- Primeira Linha -->
            <div class="col-md-4">
                <a href="vendas.php" class="menu-card dashboard-card">
                    <div class="text-center">
                        <i class='bx bx-cart-alt'></i>
                        <h5 class="mb-0">Vendas</h5>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="pedidos.php" class="menu-card dashboard-card" style="background: var(--accent-color)">
                    <div class="text-center">
                        <i class='bx bx-food-menu'></i>
                        <h5 class="mb-0">Pedidos</h5>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="cozinha.php" class="menu-card dashboard-card" style="background: var(--success-color)">
                    <div class="text-center">
                        <i class='bx bx-restaurant'></i>
                        <h5 class="mb-0">Cozinha</h5>
                    </div>
                </a>
            </div>

            <!-- Segunda Linha -->
            <div class="col-md-4">
                <a href="estoque.php" class="menu-card dashboard-card" style="background: var(--warning-color)">
                    <div class="text-center">
                        <i class='bx bx-package'></i>
                        <h5 class="mb-0">Estoque</h5>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="cadastrar_produto.php" class="menu-card dashboard-card" style="background: var(--secondary-color)">
                    <div class="text-center">
                        <i class='bx bx-plus-circle'></i>
                        <h5 class="mb-0">Cadastrar Produto</h5>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="relatorios.php" class="menu-card dashboard-card" style="background: var(--primary-color)">
                    <div class="text-center">
                        <i class='bx bx-line-chart'></i>
                        <h5 class="mb-0">Relatórios</h5>
                    </div>
                </a>
            </div>

            <!-- Terceira Linha -->
            <div class="col-md-4">
                <a href="cadastrar_funcionario.php" class="menu-card dashboard-card" style="background: #8e44ad">
                    <div class="text-center">
                        <i class='bx bx-user-plus'></i>
                        <h5 class="mb-0">Cadastrar Funcionário</h5>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="ponto.php" class="menu-card dashboard-card" style="background: #16a085">
                    <div class="text-center">
                        <i class='bx bx-time'></i>
                        <h5 class="mb-0">Ponto dos Funcionários</h5>
                    </div>
                </a>
            </div>
            <div class="col-md-4">
                <a href="configuracoes.php" class="menu-card dashboard-card" style="background: #7f8c8d">
                    <div class="text-center">
                        <i class='bx bx-cog'></i>
                        <h5 class="mb-0">Configurações</h5>
                    </div>
                </a>
            </div>
        </div>

        <!-- Botão de Sair -->
        <div class="row mt-4">
            <div class="col-12 text-center">
                <a href="logout.php" class="btn btn-danger btn-lg">
                    <i class='bx bx-log-out'></i> Sair do Sistema
                </a>
            </div>
        </div>

        <!-- Footer -->
        <footer class="footer">
            <p class="mb-0">© <?php echo date('Y'); ?> - Sistema de Gerenciamento. Todos os direitos reservados.</p>
        </footer>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>