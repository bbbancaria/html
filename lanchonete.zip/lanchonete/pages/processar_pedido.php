<?php
include '../includes/conexao.php';

$message = '';
$mesa = '';
$garcom_id = '';
$produtos = [];
$quantidades = [];

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    try {
        // Obtendo os dados do formulário
        $mesa = $_POST['mesa'];
        $garcom_id = $_POST['garcom'];
        $hora_pedido = date('Y-m-d H:i:s');
        $produtos = $_POST['produto'];
        $quantidades = $_POST['quantidade'];

        // Iniciando uma transação
        $pdo->beginTransaction();

        foreach ($produtos as $index => $produto_id) {
            $quantidade = $quantidades[$index];

            // Verifica se o estoque é suficiente
            $stmtEstoque = $pdo->prepare("SELECT estoque, nome FROM produtos WHERE id = :produto_id");
            $stmtEstoque->execute([':produto_id' => $produto_id]);
            $produto = $stmtEstoque->fetch(PDO::FETCH_ASSOC);

            if ($produto['estoque'] < $quantidade) {
                $message = "Estoque insuficiente para o produto: {$produto['nome']}. Estoque disponível: {$produto['estoque']}, Quantidade solicitada: {$quantidade}.";
                throw new Exception($message);
            }

            // Atualiza o estoque
            $novoEstoque = $produto['estoque'] - $quantidade;
            $stmtUpdateEstoque = $pdo->prepare("UPDATE produtos SET estoque = :novoEstoque WHERE id = :produto_id");
            $stmtUpdateEstoque->execute([':novoEstoque' => $novoEstoque, ':produto_id' => $produto_id]);

            // Insere o pedido
            $stmt = $pdo->prepare("INSERT INTO pedidos (mesa, produto_id, quantidade, garcom_id, hora_pedido, status) 
                                   VALUES (:mesa, :produto_id, :quantidade, :garcom_id, :hora_pedido, 'pendente')");
            $stmt->execute([
                ':mesa' => $mesa,
                ':produto_id' => $produto_id,
                ':quantidade' => $quantidade,
                ':garcom_id' => $garcom_id,
                ':hora_pedido' => $hora_pedido,
            ]);
        }

        // Finalizando a transação
        $pdo->commit();
        $message = "Pedido registrado com sucesso! Você pode adicionar mais produtos.";
    } catch (Exception $e) {
        $pdo->rollBack();
        $message = $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registrar Pedido</title>
    <link rel="stylesheet" href="../assets/css/global.css">
</head>
<body>
    <div class="container">
        <h1>Registrar Pedido</h1>

        <?php if (!empty($message)): ?>
            <div class="alert">
                <?= htmlspecialchars($message); ?>
            </div>
        <?php endif; ?>

        <form method="POST" action="processar_pedido.php">
            <div>
                <label for="mesa">Mesa:</label>
                <input type="text" id="mesa" name="mesa" value="<?= htmlspecialchars($mesa); ?>" required>
            </div>
            <div>
                <label for="garcom">Garçom:</label>
                <select id="garcom" name="garcom" required>
                    <?php
                    $stmtGarcom = $pdo->query("SELECT id, nome FROM funcionarios WHERE cargo = 'garcom'");
                    while ($garcom = $stmtGarcom->fetch(PDO::FETCH_ASSOC)) {
                        $selected = $garcom_id == $garcom['id'] ? 'selected' : '';
                        echo "<option value='{$garcom['id']}' $selected>{$garcom['nome']}</option>";
                    }
                    ?>
                </select>
            </div>

            <div id="produtos-container">
                <?php if (!empty($produtos)): ?>
                    <?php foreach ($produtos as $index => $produto_id): ?>
                        <div class="produto">
                            <label for="produto">Produto:</label>
                            <select name="produto[]" required>
                                <?php
                                $stmtProdutos = $pdo->query("SELECT id, nome FROM produtos");
                                while ($produto = $stmtProdutos->fetch(PDO::FETCH_ASSOC)) {
                                    $selected = $produto_id == $produto['id'] ? 'selected' : '';
                                    echo "<option value='{$produto['id']}' $selected>{$produto['nome']}</option>";
                                }
                                ?>
                            </select>
                            <label for="quantidade">Quantidade:</label>
                            <input type="number" name="quantidade[]" value="<?= htmlspecialchars($quantidades[$index]); ?>" required>
                        </div>
                    <?php endforeach; ?>
                <?php else: ?>
                    <div class="produto">
                        <label for="produto">Produto:</label>
                        <select name="produto[]" required>
                            <?php
                            $stmtProdutos = $pdo->query("SELECT id, nome FROM produtos");
                            while ($produto = $stmtProdutos->fetch(PDO::FETCH_ASSOC)) {
                                echo "<option value='{$produto['id']}'>{$produto['nome']}</option>";
                            }
                            ?>
                        </select>
                        <label for="quantidade">Quantidade:</label>
                        <input type="number" name="quantidade[]" required>
                    </div>
                <?php endif; ?>
            </div>

            <button type="button" id="add-product">Adicionar Mais Produtos</button>
            <button type="submit">Finalizar Pedido</button>
        </form>

        <a href="dashboard.php" class="btn btn-secondary">Voltar ao Dashboard</a>
    </div>

    <script>
        document.getElementById('add-product').addEventListener('click', function () {
            const container = document.getElementById('produtos-container');
            const newProduct = `
                <div class="produto">
                    <label for="produto">Produto:</label>
                    <select name="produto[]" required>
                        <?php
                        $stmtProdutos = $pdo->query("SELECT id, nome FROM produtos");
                        while ($produto = $stmtProdutos->fetch(PDO::FETCH_ASSOC)) {
                            echo "<option value='{$produto['id']}'>{$produto['nome']}</option>";
                        }
                        ?>
                    </select>
                    <label for="quantidade">Quantidade:</label>
                    <input type="number" name="quantidade[]" required>
                </div>
            `;
            container.insertAdjacentHTML('beforeend', newProduct);
        });
    </script>
</body>
</html>
