<?php
session_start();
require_once '../includes/conexao.php';

// Verifica autenticação
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Função para determinar a classe de tempo
function getTempoClass($minutos) {
    if ($minutos > 30) return 'bg-danger';
    if ($minutos > 15) return 'bg-warning';
    return 'bg-success';
}

try {
    // Busca pedidos pendentes e em preparo com detalhes
    $stmt = $pdo->query("
        SELECT p.*, u.nome as garcom_nome,
        GROUP_CONCAT(CONCAT(ip.quantidade, 'x ', pr.nome) SEPARATOR '\n') as itens_detalhes,
        TIMESTAMPDIFF(MINUTE, p.data_hora, NOW()) as tempo_espera
        FROM pedidos p
        LEFT JOIN usuarios u ON p.garcom_id = u.id
        LEFT JOIN itens_pedido ip ON p.id = ip.pedido_id
        LEFT JOIN produtos pr ON ip.produto_id = pr.id
        WHERE p.status IN ('pendente', 'preparando')
        GROUP BY p.id
        ORDER BY p.data_hora ASC
    ");
    $pedidos = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    error_log("Erro ao buscar pedidos: " . $e->getMessage());
    $pedidos = [];
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cozinha - Sistema</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/boxicons@2.0.7/css/boxicons.min.css" rel="stylesheet">
    <style>
        .pedido-card {
            transition: all 0.3s ease;
        }
        .pedido-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }
        .tempo-badge {
            position: absolute;
            top: 10px;
            right: 10px;
            padding: 5px 10px;
            border-radius: 15px;
            font-size: 0.9rem;
        }
    </style>
</head>
<body>
    <div class="container-fluid p-4">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h1>Pedidos na Cozinha</h1>
            <div>
                <button id="toggleSound" class="btn btn-outline-secondary">
                    <i class='bx bxs-volume-full'></i> Som
                </button>
                <button onclick="location.reload()" class="btn btn-primary ms-2">
                    <i class='bx bx-refresh'></i> Atualizar
                </button>
            </div>
        </div>

        <div class="row" id="pedidos-container">
            <?php foreach ($pedidos as $pedido): ?>
                <div class="col-12 col-md-6 col-lg-4 mb-4">
                    <div class="card pedido-card h-100">
                        <div class="card-body">
                            <span class="tempo-badge <?php echo getTempoClass($pedido['tempo_espera']); ?>">
                                <?php echo $pedido['tempo_espera']; ?> min
                            </span>
                            <h5 class="card-title">Pedido #<?php echo $pedido['id']; ?></h5>
                            <h6 class="card-subtitle mb-2 text-muted">
                                Garçom: <?php echo htmlspecialchars($pedido['garcom_nome']); ?>
                            </h6>
                            <p class="card-text">
                                <strong>Itens:</strong><br>
                                <?php echo nl2br(htmlspecialchars($pedido['itens_detalhes'])); ?>
                            </p>
                            <p class="card-text">
                                <small class="text-muted">
                                    Hora: <?php echo date('H:i', strtotime($pedido['data_hora'])); ?>
                                </small>
                            </p>
                            <div class="btn-group w-100">
                                <?php if ($pedido['status'] == 'pendente'): ?>
                                    <button class="btn btn-warning" onclick="atualizarStatus(<?php echo $pedido['id']; ?>, 'preparando')">
                                        Iniciar Preparo
                                    </button>
                                <?php else: ?>
                                    <button class="btn btn-success" onclick="atualizarStatus(<?php echo $pedido['id']; ?>, 'pronto')">
                                        Marcar Pronto
                                    </button>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

    <audio id="newOrderSound" src="../assets/sounds/notification.mp3"></audio>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        let soundEnabled = localStorage.getItem('soundEnabled') !== 'false';
        const toggleSoundBtn = document.getElementById('toggleSound');
        
        function updateSoundButton() {
            toggleSoundBtn.innerHTML = `<i class='bx bxs-volume-${soundEnabled ? 'full' : 'mute'}'></i> Som ${soundEnabled ? 'ON' : 'OFF'}`;
        }
        
        updateSoundButton();
        
        toggleSoundBtn.addEventListener('click', () => {
            soundEnabled = !soundEnabled;
            localStorage.setItem('soundEnabled', soundEnabled);
            updateSoundButton();
        });

        function atualizarStatus(pedidoId, novoStatus) {
            $.post('atualizar_status_pedido.php', {
                pedido_id: pedidoId,
                status: novoStatus
            })
            .done(function(response) {
                if (response.success) {
                    location.reload();
                } else {
                    alert('Erro ao atualizar status: ' + response.error);
                }
            })
            .fail(function() {
                alert('Erro ao comunicar com o servidor');
            });
        }

        function verificarNovosPedidos() {
            $.get('buscar_pedidos_cozinha.php')
            .done(function(response) {
                if (response.success && response.novos_pedidos && soundEnabled) {
                    document.getElementById('newOrderSound').play();
                }
                if (response.success && response.atualizar) {
                    location.reload();
                }
            });
        }

        // Verificar novos pedidos a cada 30 segundos
        setInterval(verificarNovosPedidos, 30000);
    </script>
</body>
</html>