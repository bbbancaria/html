<?php
include 'includes/conexao.php';

try {
    // Lê e executa o script SQL
    $sql = file_get_contents('sql/criar_tabela_usuarios.sql');
    $pdo->exec($sql);
    
    echo "Tabela de usuários criada/atualizada com sucesso!";
    echo "<br>Você pode fazer login com:<br>";
    echo "Login: admin<br>";
    echo "Senha: admin123";
    
} catch (PDOException $e) {
    echo "Erro ao configurar o banco de dados: " . $e->getMessage();
    exit;
}
