<?php
require_once 'includes/conexao.php';

try {
    // Verifica se já existe algum garçom
    $stmt = $pdo->query("SELECT COUNT(*) as count FROM usuarios WHERE tipo = 'funcionario' AND status = 'ativo'");
    $result = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($result['count'] == 0) {
        // Insere um garçom de teste
        $sql = "INSERT INTO usuarios (nome, login, senha, tipo, status) VALUES 
                ('João Garçom', 'joao', SHA2('123456', 256), 'funcionario', 'ativo')";
        $pdo->exec($sql);
        echo "Garçom de teste criado com sucesso!";
    } else {
        echo "Já existem garçons cadastrados no sistema.";
    }
} catch (PDOException $e) {
    echo "Erro ao configurar garçons: " . $e->getMessage();
    exit;
}
